module student_mini_cpu_rom_bank_20 (sys_clk,
    address,
    data);
 input sys_clk;
 input [8:0] address;
 output [31:0] data;

 wire _0000_;
 wire _0001_;
 wire _0002_;
 wire _0003_;
 wire _0004_;
 wire _0005_;
 wire _0006_;
 wire _0007_;
 wire _0008_;
 wire _0009_;
 wire _0010_;
 wire _0011_;
 wire _0012_;
 wire _0013_;
 wire _0014_;
 wire _0015_;
 wire _0016_;
 wire _0017_;
 wire _0018_;
 wire _0019_;
 wire _0020_;
 wire _0021_;
 wire _0022_;
 wire _0023_;
 wire _0024_;
 wire _0025_;
 wire _0026_;
 wire _0027_;
 wire _0028_;
 wire _0029_;
 wire _0030_;
 wire _0031_;
 wire _0032_;
 wire _0034_;
 wire _0035_;
 wire _0036_;
 wire _0038_;
 wire _0039_;
 wire _0040_;
 wire _0042_;
 wire _0044_;
 wire _0045_;
 wire _0046_;
 wire _0047_;
 wire _0050_;
 wire _0053_;
 wire _0056_;
 wire _0058_;
 wire _0059_;
 wire _0060_;
 wire _0062_;
 wire _0063_;
 wire _0064_;
 wire _0065_;
 wire _0068_;
 wire _0070_;
 wire _0071_;
 wire _0072_;
 wire _0074_;
 wire _0075_;
 wire _0076_;
 wire _0078_;
 wire _0079_;
 wire _0080_;
 wire _0082_;
 wire _0083_;
 wire _0084_;
 wire _0086_;
 wire _0087_;
 wire _0088_;
 wire _0090_;
 wire _0091_;
 wire _0092_;
 wire _0093_;
 wire _0099_;
 wire _0102_;
 wire _0106_;
 wire _0110_;
 wire _0111_;
 wire _0112_;
 wire _0114_;
 wire _0115_;
 wire _0116_;
 wire _0117_;
 wire _0119_;
 wire _0122_;
 wire _0123_;
 wire _0125_;
 wire _0127_;
 wire _0128_;
 wire _0129_;
 wire _0132_;
 wire _0133_;
 wire _0134_;
 wire _0135_;
 wire _0137_;
 wire _0138_;
 wire _0140_;
 wire _0142_;
 wire _0143_;
 wire _0144_;
 wire _0146_;
 wire _0148_;
 wire _0150_;
 wire _0152_;
 wire _0153_;
 wire _0155_;
 wire _0159_;
 wire _0161_;
 wire _0165_;
 wire _0167_;
 wire _0168_;
 wire _0169_;
 wire _0171_;
 wire clknet_2_2__leaf_sys_clk;
 wire _0173_;
 wire net109;
 wire _0175_;
 wire _0176_;
 wire _0177_;
 wire net101;
 wire _0179_;
 wire _0180_;
 wire _0181_;
 wire _0182_;
 wire _0183_;
 wire _0184_;
 wire _0185_;
 wire net99;
 wire _0187_;
 wire _0188_;
 wire _0189_;
 wire _0190_;
 wire _0191_;
 wire net96;
 wire _0193_;
 wire _0194_;
 wire _0195_;
 wire _0196_;
 wire _0197_;
 wire _0198_;
 wire _0199_;
 wire net94;
 wire _0201_;
 wire _0202_;
 wire _0203_;
 wire _0204_;
 wire _0205_;
 wire net92;
 wire _0207_;
 wire net91;
 wire _0209_;
 wire _0210_;
 wire net88;
 wire net87;
 wire _0213_;
 wire net86;
 wire _0215_;
 wire _0216_;
 wire net85;
 wire _0218_;
 wire _0219_;
 wire net84;
 wire net104;
 wire net103;
 wire _0223_;
 wire net102;
 wire _0225_;
 wire _0226_;
 wire _0227_;
 wire _0228_;
 wire _0229_;
 wire _0230_;
 wire _0231_;
 wire net95;
 wire _0233_;
 wire _0234_;
 wire _0235_;
 wire net83;
 wire _0237_;
 wire _0238_;
 wire _0239_;
 wire net81;
 wire _0241_;
 wire _0242_;
 wire _0243_;
 wire _0244_;
 wire _0245_;
 wire _0246_;
 wire _0247_;
 wire _0248_;
 wire _0249_;
 wire clknet_2_0__leaf_sys_clk;
 wire _0251_;
 wire _0252_;
 wire _0253_;
 wire _0254_;
 wire clknet_0_sys_clk;
 wire _0256_;
 wire _0257_;
 wire _0258_;
 wire net115;
 wire _0260_;
 wire _0261_;
 wire _0262_;
 wire _0263_;
 wire _0264_;
 wire net117;
 wire _0266_;
 wire net114;
 wire _0268_;
 wire _0269_;
 wire _0270_;
 wire _0271_;
 wire _0272_;
 wire _0273_;
 wire _0274_;
 wire _0275_;
 wire _0276_;
 wire net111;
 wire _0278_;
 wire _0279_;
 wire _0280_;
 wire _0281_;
 wire _0282_;
 wire _0283_;
 wire _0284_;
 wire _0285_;
 wire _0286_;
 wire _0287_;
 wire _0288_;
 wire _0289_;
 wire net110;
 wire _0291_;
 wire _0292_;
 wire _0293_;
 wire _0294_;
 wire _0295_;
 wire _0296_;
 wire _0297_;
 wire _0298_;
 wire net107;
 wire _0300_;
 wire _0301_;
 wire net106;
 wire _0303_;
 wire _0304_;
 wire _0305_;
 wire _0306_;
 wire _0307_;
 wire _0308_;
 wire _0309_;
 wire _0310_;
 wire _0311_;
 wire _0312_;
 wire _0313_;
 wire _0314_;
 wire _0315_;
 wire _0316_;
 wire _0317_;
 wire _0318_;
 wire _0319_;
 wire _0320_;
 wire _0321_;
 wire _0322_;
 wire _0323_;
 wire _0324_;
 wire _0325_;
 wire _0326_;
 wire _0327_;
 wire _0328_;
 wire _0329_;
 wire _0330_;
 wire _0331_;
 wire _0332_;
 wire _0333_;
 wire _0334_;
 wire _0335_;
 wire _0336_;
 wire _0337_;
 wire _0338_;
 wire _0339_;
 wire _0340_;
 wire _0341_;
 wire _0342_;
 wire _0343_;
 wire _0345_;
 wire _0346_;
 wire _0347_;
 wire _0348_;
 wire _0349_;
 wire _0350_;
 wire _0351_;
 wire _0352_;
 wire _0353_;
 wire _0354_;
 wire _0356_;
 wire _0357_;
 wire _0358_;
 wire _0360_;
 wire _0361_;
 wire _0362_;
 wire _0363_;
 wire _0364_;
 wire clknet_2_3__leaf_sys_clk;
 wire _0366_;
 wire _0367_;
 wire _0368_;
 wire _0369_;
 wire _0370_;
 wire _0371_;
 wire _0372_;
 wire _0373_;
 wire _0374_;
 wire _0375_;
 wire net113;
 wire _0377_;
 wire _0378_;
 wire _0379_;
 wire _0380_;
 wire _0381_;
 wire _0382_;
 wire _0383_;
 wire _0384_;
 wire _0385_;
 wire _0387_;
 wire _0388_;
 wire _0389_;
 wire _0390_;
 wire _0391_;
 wire _0392_;
 wire _0393_;
 wire _0394_;
 wire _0395_;
 wire _0397_;
 wire _0398_;
 wire _0399_;
 wire _0400_;
 wire _0401_;
 wire _0402_;
 wire _0403_;
 wire _0404_;
 wire _0405_;
 wire _0406_;
 wire _0408_;
 wire _0409_;
 wire _0410_;
 wire _0411_;
 wire _0412_;
 wire _0413_;
 wire _0414_;
 wire _0415_;
 wire _0416_;
 wire _0418_;
 wire _0419_;
 wire _0420_;
 wire _0421_;
 wire _0422_;
 wire _0423_;
 wire _0424_;
 wire _0425_;
 wire _0426_;
 wire _0427_;
 wire _0429_;
 wire _0430_;
 wire _0431_;
 wire _0432_;
 wire _0434_;
 wire _0435_;
 wire _0436_;
 wire _0437_;
 wire _0439_;
 wire _0440_;
 wire _0441_;
 wire _0442_;
 wire _0443_;
 wire _0444_;
 wire _0446_;
 wire _0447_;
 wire _0448_;
 wire _0450_;
 wire _0451_;
 wire _0452_;
 wire _0453_;
 wire _0454_;
 wire _0455_;
 wire _0456_;
 wire _0457_;
 wire _0458_;
 wire _0459_;
 wire _0460_;
 wire _0461_;
 wire _0462_;
 wire _0463_;
 wire _0464_;
 wire _0465_;
 wire _0466_;
 wire _0467_;
 wire _0468_;
 wire _0469_;
 wire _0470_;
 wire _0471_;
 wire _0472_;
 wire _0473_;
 wire _0474_;
 wire _0475_;
 wire _0476_;
 wire _0477_;
 wire _0478_;
 wire _0479_;
 wire _0481_;
 wire _0482_;
 wire _0483_;
 wire _0484_;
 wire _0485_;
 wire _0486_;
 wire _0487_;
 wire _0488_;
 wire _0489_;
 wire _0491_;
 wire _0492_;
 wire _0493_;
 wire _0494_;
 wire _0495_;
 wire _0496_;
 wire _0497_;
 wire _0498_;
 wire _0499_;
 wire _0500_;
 wire _0502_;
 wire _0503_;
 wire _0504_;
 wire _0505_;
 wire _0506_;
 wire _0507_;
 wire _0508_;
 wire _0509_;
 wire _0510_;
 wire _0511_;
 wire _0512_;
 wire _0513_;
 wire _0514_;
 wire _0515_;
 wire _0516_;
 wire _0517_;
 wire _0518_;
 wire _0519_;
 wire _0520_;
 wire _0521_;
 wire _0522_;
 wire _0523_;
 wire _0524_;
 wire _0525_;
 wire _0526_;
 wire _0527_;
 wire _0528_;
 wire _0529_;
 wire _0530_;
 wire _0531_;
 wire _0532_;
 wire _0533_;
 wire _0534_;
 wire _0535_;
 wire _0536_;
 wire _0537_;
 wire _0538_;
 wire _0539_;
 wire _0540_;
 wire _0541_;
 wire _0542_;
 wire _0543_;
 wire _0544_;
 wire _0545_;
 wire _0546_;
 wire _0547_;
 wire _0548_;
 wire _0549_;
 wire _0550_;
 wire _0551_;
 wire _0552_;
 wire _0553_;
 wire _0554_;
 wire _0555_;
 wire _0556_;
 wire _0557_;
 wire _0558_;
 wire _0559_;
 wire _0560_;
 wire _0561_;
 wire _0562_;
 wire _0563_;
 wire net100;
 wire _0565_;
 wire _0566_;
 wire _0567_;
 wire _0568_;
 wire _0569_;
 wire _0570_;
 wire _0571_;
 wire _0572_;
 wire _0573_;
 wire _0574_;
 wire net97;
 wire _0576_;
 wire _0577_;
 wire _0578_;
 wire _0579_;
 wire _0580_;
 wire _0581_;
 wire _0582_;
 wire _0583_;
 wire _0584_;
 wire _0585_;
 wire net93;
 wire _0587_;
 wire _0588_;
 wire _0589_;
 wire _0590_;
 wire _0591_;
 wire _0592_;
 wire _0593_;
 wire _0594_;
 wire _0595_;
 wire net89;
 wire _0597_;
 wire _0598_;
 wire _0599_;
 wire _0600_;
 wire _0601_;
 wire _0602_;
 wire _0603_;
 wire _0604_;
 wire _0605_;
 wire _0606_;
 wire net108;
 wire _0608_;
 wire _0609_;
 wire _0610_;
 wire _0611_;
 wire _0612_;
 wire _0613_;
 wire _0614_;
 wire _0615_;
 wire _0616_;
 wire _0617_;
 wire net98;
 wire _0619_;
 wire _0620_;
 wire _0621_;
 wire _0622_;
 wire _0623_;
 wire _0624_;
 wire _0625_;
 wire _0626_;
 wire _0627_;
 wire _0628_;
 wire net82;
 wire _0630_;
 wire _0631_;
 wire _0632_;
 wire _0633_;
 wire _0634_;
 wire _0635_;
 wire _0636_;
 wire _0637_;
 wire _0638_;
 wire _0639_;
 wire net90;
 wire _0641_;
 wire _0642_;
 wire _0643_;
 wire _0644_;
 wire _0645_;
 wire _0646_;
 wire _0647_;
 wire _0648_;
 wire _0649_;
 wire net116;
 wire _0651_;
 wire _0652_;
 wire _0653_;
 wire _0654_;
 wire _0655_;
 wire _0656_;
 wire _0657_;
 wire _0658_;
 wire _0659_;
 wire _0660_;
 wire clknet_2_1__leaf_sys_clk;
 wire _0662_;
 wire _0663_;
 wire _0664_;
 wire _0665_;
 wire _0666_;
 wire _0667_;
 wire _0668_;
 wire _0669_;
 wire _0670_;
 wire _0671_;
 wire _0672_;
 wire _0673_;
 wire _0674_;
 wire _0675_;
 wire _0676_;
 wire _0677_;
 wire _0678_;
 wire _0679_;
 wire _0680_;
 wire _0681_;
 wire _0682_;
 wire _0683_;
 wire _0684_;
 wire _0685_;
 wire _0686_;
 wire _0687_;
 wire _0688_;
 wire _0689_;
 wire _0690_;
 wire _0691_;
 wire net112;
 wire _0693_;
 wire _0694_;
 wire _0695_;
 wire _0696_;
 wire _0697_;
 wire _0698_;
 wire _0699_;
 wire _0700_;
 wire _0701_;
 wire _0702_;
 wire _0703_;
 wire _0704_;
 wire _0705_;
 wire _0706_;
 wire _0707_;
 wire _0708_;
 wire _0709_;
 wire _0710_;
 wire _0711_;
 wire _0712_;
 wire _0713_;
 wire _0714_;
 wire _0715_;
 wire _0716_;
 wire _0717_;
 wire _0718_;
 wire _0719_;
 wire _0720_;
 wire _0721_;
 wire _0722_;
 wire net105;
 wire _0724_;
 wire _0725_;
 wire _0726_;
 wire _0727_;
 wire _0728_;
 wire _0729_;
 wire _0730_;
 wire _0731_;
 wire _0732_;
 wire _0733_;
 wire _0735_;
 wire _0736_;
 wire _0737_;
 wire _0738_;
 wire _0739_;
 wire _0740_;
 wire _0741_;
 wire _0742_;
 wire _0743_;
 wire _0744_;
 wire _0746_;
 wire _0747_;
 wire _0748_;
 wire _0749_;
 wire _0750_;
 wire _0751_;
 wire _0752_;
 wire _0753_;
 wire _0755_;
 wire _0756_;
 wire _0757_;
 wire _0758_;
 wire _0759_;
 wire _0760_;
 wire _0761_;
 wire _0762_;
 wire _0763_;
 wire _0765_;
 wire _0766_;
 wire _0767_;
 wire _0768_;
 wire _0769_;
 wire _0770_;
 wire _0771_;
 wire _0772_;
 wire _0773_;
 wire _0774_;
 wire _0776_;
 wire _0777_;
 wire _0778_;
 wire _0779_;
 wire _0780_;
 wire _0781_;
 wire _0782_;
 wire _0783_;
 wire _0784_;
 wire _0785_;
 wire _0787_;
 wire _0788_;
 wire _0789_;
 wire _0790_;
 wire _0791_;
 wire _0792_;
 wire _0793_;
 wire _0794_;
 wire _0795_;
 wire _0796_;
 wire _0797_;
 wire _0798_;
 wire _0799_;
 wire _0800_;
 wire _0801_;
 wire _0802_;
 wire _0803_;
 wire _0804_;
 wire _0805_;
 wire _0806_;
 wire _0808_;
 wire _0809_;
 wire _0810_;
 wire _0811_;
 wire _0812_;
 wire _0813_;
 wire _0814_;
 wire _0815_;
 wire _0816_;
 wire _0817_;
 wire _0818_;
 wire _0819_;
 wire _0820_;
 wire _0821_;
 wire _0822_;
 wire _0823_;
 wire _0824_;
 wire _0825_;
 wire _0826_;
 wire _0827_;
 wire _0828_;
 wire _0830_;
 wire _0831_;
 wire _0832_;
 wire _0833_;
 wire _0834_;
 wire _0835_;
 wire _0836_;
 wire _0837_;
 wire _0838_;
 wire _0839_;
 wire _0840_;
 wire _0841_;
 wire _0842_;
 wire _0843_;
 wire _0844_;
 wire _0845_;
 wire _0846_;
 wire _0847_;
 wire _0848_;
 wire _0849_;
 wire _0850_;
 wire _0851_;
 wire _0852_;
 wire _0853_;
 wire _0854_;
 wire _0855_;
 wire _0856_;
 wire _0857_;
 wire _0858_;
 wire _0859_;
 wire _0860_;
 wire _0862_;
 wire _0863_;
 wire _0864_;
 wire _0865_;
 wire _0866_;
 wire _0867_;
 wire _0868_;
 wire _0869_;
 wire _0870_;
 wire _0872_;
 wire _0873_;
 wire _0874_;
 wire _0875_;
 wire _0876_;
 wire _0877_;
 wire _0878_;
 wire _0879_;
 wire _0884_;
 wire net1;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire net35;
 wire net36;
 wire net37;
 wire net38;
 wire net39;
 wire net40;
 wire net41;

 sky130_fd_sc_hd__o21ai_0 _0890_ (.A1(net101),
    .A2(_0071_),
    .B1(_0072_),
    .Y(_0074_));
 sky130_fd_sc_hd__o211ai_1 _0891_ (.A1(_0046_),
    .A2(_0065_),
    .B1(net97),
    .C1(_0074_),
    .Y(_0075_));
 sky130_fd_sc_hd__nor2_2 _0892_ (.A(net114),
    .B(net3),
    .Y(_0076_));
 sky130_fd_sc_hd__nor2_2 _0894_ (.A(net98),
    .B(net104),
    .Y(_0078_));
 sky130_fd_sc_hd__nand2_1 _0895_ (.A(_0076_),
    .B(net95),
    .Y(_0079_));
 sky130_fd_sc_hd__inv_1 _0896_ (.A(net108),
    .Y(_0080_));
 sky130_fd_sc_hd__nand2_1 _0898_ (.A(net94),
    .B(_0072_),
    .Y(_0082_));
 sky130_fd_sc_hd__nor2_1 _0899_ (.A(_0079_),
    .B(_0082_),
    .Y(_0083_));
 sky130_fd_sc_hd__a21o_1 _0900_ (.A1(net4),
    .A2(net110),
    .B1(net102),
    .X(_0459_));
 sky130_fd_sc_hd__a21oi_1 _0901_ (.A1(_0060_),
    .A2(_0083_),
    .B1(net9),
    .Y(_0084_));
 sky130_fd_sc_hd__o211a_1 _0903_ (.A1(net117),
    .A2(net113),
    .B1(net110),
    .C1(net4),
    .X(_0086_));
 sky130_fd_sc_hd__o21ai_1 _0904_ (.A1(net103),
    .A2(_0086_),
    .B1(net101),
    .Y(_0087_));
 sky130_fd_sc_hd__nand2_1 _0905_ (.A(_0060_),
    .B(_0087_),
    .Y(_0088_));
 sky130_fd_sc_hd__a21oi_1 _0907_ (.A1(net9),
    .A2(_0088_),
    .B1(net96),
    .Y(_0090_));
 sky130_fd_sc_hd__nor2_1 _0908_ (.A(_0084_),
    .B(_0090_),
    .Y(_0091_));
 sky130_fd_sc_hd__a31o_2 _0909_ (.A1(net90),
    .A2(_0062_),
    .A3(_0075_),
    .B1(_0091_),
    .X(_0002_));
 sky130_fd_sc_hd__nand2_1 _0910_ (.A(_0511_),
    .B(_0087_),
    .Y(_0092_));
 sky130_fd_sc_hd__nand2_1 _0911_ (.A(net6),
    .B(_0459_),
    .Y(_0470_));
 sky130_fd_sc_hd__nand2_1 _0912_ (.A(net9),
    .B(_0092_),
    .Y(_0093_));
 sky130_fd_sc_hd__inv_2 _0918_ (.A(net3),
    .Y(_0099_));
 sky130_fd_sc_hd__or2_1 _0921_ (.A(net117),
    .B(net113),
    .X(_0102_));
 sky130_fd_sc_hd__nand3_1 _0926_ (.A(net116),
    .B(net114),
    .C(net111),
    .Y(_0106_));
 sky130_fd_sc_hd__a21oi_1 _0930_ (.A1(net93),
    .A2(_0106_),
    .B1(net109),
    .Y(_0110_));
 sky130_fd_sc_hd__a31oi_1 _0931_ (.A1(net109),
    .A2(_0099_),
    .A3(_0038_),
    .B1(_0110_),
    .Y(_0111_));
 sky130_fd_sc_hd__nor2b_1 _0932_ (.A(net103),
    .B_N(net115),
    .Y(_0112_));
 sky130_fd_sc_hd__nand2_1 _0935_ (.A(net107),
    .B(net83),
    .Y(_0114_));
 sky130_fd_sc_hd__nor4b_1 _0936_ (.A(net9),
    .B(net96),
    .C(net101),
    .D_N(net97),
    .Y(_0115_));
 sky130_fd_sc_hd__o221ai_1 _0937_ (.A1(net103),
    .A2(_0111_),
    .B1(_0112_),
    .B2(_0114_),
    .C1(_0115_),
    .Y(_0116_));
 sky130_fd_sc_hd__nand2_1 _0938_ (.A(net117),
    .B(net113),
    .Y(_0117_));
 sky130_fd_sc_hd__nor2_1 _0940_ (.A(net103),
    .B(_0117_),
    .Y(_0119_));
 sky130_fd_sc_hd__nand2_1 _0943_ (.A(net109),
    .B(net110),
    .Y(_0122_));
 sky130_fd_sc_hd__a21oi_1 _0945_ (.A1(net103),
    .A2(_0117_),
    .B1(_0122_),
    .Y(_0123_));
 sky130_fd_sc_hd__o21ai_0 _0947_ (.A1(_0119_),
    .A2(_0123_),
    .B1(net101),
    .Y(_0125_));
 sky130_fd_sc_hd__nor3b_1 _0949_ (.A(net113),
    .B(net110),
    .C_N(net109),
    .Y(_0127_));
 sky130_fd_sc_hd__or2_1 _0950_ (.A(net99),
    .B(net115),
    .X(_0128_));
 sky130_fd_sc_hd__nor2_1 _0951_ (.A(net109),
    .B(_0128_),
    .Y(_0129_));
 sky130_fd_sc_hd__o21ai_0 _0954_ (.A1(_0127_),
    .A2(_0129_),
    .B1(net103),
    .Y(_0132_));
 sky130_fd_sc_hd__nor2_1 _0955_ (.A(net96),
    .B(net97),
    .Y(_0511_));
 sky130_fd_sc_hd__and2_1 _0956_ (.A(net116),
    .B(net3),
    .X(_0133_));
 sky130_fd_sc_hd__nor2b_1 _0957_ (.A(net103),
    .B_N(net107),
    .Y(_0134_));
 sky130_fd_sc_hd__clkinv_1 _0958_ (.A(net104),
    .Y(_0135_));
 sky130_fd_sc_hd__nand2_1 _0960_ (.A(net92),
    .B(_0046_),
    .Y(_0137_));
 sky130_fd_sc_hd__inv_1 _0961_ (.A(net114),
    .Y(_0138_));
 sky130_fd_sc_hd__nand2_1 _0963_ (.A(net106),
    .B(_0138_),
    .Y(_0140_));
 sky130_fd_sc_hd__a21oi_1 _0965_ (.A1(_0137_),
    .A2(_0140_),
    .B1(net100),
    .Y(_0142_));
 sky130_fd_sc_hd__nand2_1 _0966_ (.A(_0470_),
    .B(_0511_),
    .Y(_0522_));
 sky130_fd_sc_hd__a21oi_1 _0967_ (.A1(_0133_),
    .A2(_0134_),
    .B1(_0142_),
    .Y(_0143_));
 sky130_fd_sc_hd__nand2b_1 _0968_ (.A_N(net3),
    .B(net116),
    .Y(_0144_));
 sky130_fd_sc_hd__a21oi_1 _0970_ (.A1(_0796_),
    .A2(_0144_),
    .B1(net113),
    .Y(_0146_));
 sky130_fd_sc_hd__o21ai_0 _0972_ (.A1(net101),
    .A2(net113),
    .B1(net115),
    .Y(_0148_));
 sky130_fd_sc_hd__a21oi_1 _0974_ (.A1(net86),
    .A2(_0148_),
    .B1(net103),
    .Y(_0150_));
 sky130_fd_sc_hd__o21ai_0 _0976_ (.A1(_0146_),
    .A2(_0150_),
    .B1(net94),
    .Y(_0152_));
 sky130_fd_sc_hd__nand2_1 _0977_ (.A(net9),
    .B(_0522_),
    .Y(_0533_));
 sky130_fd_sc_hd__nand2_1 _0978_ (.A(_0060_),
    .B(net90),
    .Y(_0153_));
 sky130_fd_sc_hd__a41o_1 _0980_ (.A1(_0125_),
    .A2(_0132_),
    .A3(_0143_),
    .A4(_0152_),
    .B1(_0153_),
    .X(_0155_));
 sky130_fd_sc_hd__nand3_1 _0981_ (.A(_0093_),
    .B(_0116_),
    .C(_0155_),
    .Y(_0029_));
 sky130_fd_sc_hd__nand2b_1 _0985_ (.A_N(net114),
    .B(net104),
    .Y(_0159_));
 sky130_fd_sc_hd__o21ai_0 _0987_ (.A1(net103),
    .A2(_0068_),
    .B1(_0159_),
    .Y(_0161_));
 sky130_fd_sc_hd__inv_1 _0988_ (.A(_0533_),
    .Y(_0031_));
 sky130_fd_sc_hd__nand2_1 _0992_ (.A(net110),
    .B(net95),
    .Y(_0165_));
 sky130_fd_sc_hd__a21oi_1 _0994_ (.A1(_0818_),
    .A2(_0165_),
    .B1(net113),
    .Y(_0167_));
 sky130_fd_sc_hd__a21oi_1 _0995_ (.A1(net101),
    .A2(_0161_),
    .B1(_0167_),
    .Y(_0168_));
 sky130_fd_sc_hd__nand2_1 _0996_ (.A(net101),
    .B(net103),
    .Y(_0169_));
 sky130_fd_sc_hd__nor2b_1 _0998_ (.A(net3),
    .B_N(net114),
    .Y(_0171_));
 sky130_fd_sc_hd__nor2_1 _1000_ (.A(net9),
    .B(net96),
    .Y(_0553_));
 sky130_fd_sc_hd__nor2b_1 _1002_ (.A(net114),
    .B_N(net104),
    .Y(_0173_));
 sky130_fd_sc_hd__a22oi_1 _1004_ (.A1(net92),
    .A2(net91),
    .B1(_0173_),
    .B2(net111),
    .Y(_0175_));
 sky130_fd_sc_hd__o22ai_1 _1005_ (.A1(_0068_),
    .A2(_0169_),
    .B1(_0175_),
    .B2(net101),
    .Y(_0176_));
 sky130_fd_sc_hd__nand2_1 _1006_ (.A(net107),
    .B(_0176_),
    .Y(_0177_));
 sky130_fd_sc_hd__a211oi_1 _1008_ (.A1(_0076_),
    .A2(_0032_),
    .B1(_0153_),
    .C1(net115),
    .Y(_0179_));
 sky130_fd_sc_hd__o211ai_1 _1009_ (.A1(net107),
    .A2(_0168_),
    .B1(_0177_),
    .C1(_0179_),
    .Y(_0180_));
 sky130_fd_sc_hd__nor2_1 _1010_ (.A(net109),
    .B(net115),
    .Y(_0181_));
 sky130_fd_sc_hd__and3_1 _1012_ (.A(_0181_),
    .B(_0064_),
    .C(_0115_),
    .X(_0182_));
 sky130_fd_sc_hd__nor2_1 _1013_ (.A(_0031_),
    .B(_0182_),
    .Y(_0183_));
 sky130_fd_sc_hd__nor2_1 _1014_ (.A(net92),
    .B(_0099_),
    .Y(_0184_));
 sky130_fd_sc_hd__nand2b_1 _1015_ (.A_N(net100),
    .B(net112),
    .Y(_0185_));
 sky130_fd_sc_hd__a21boi_0 _1017_ (.A1(_0040_),
    .A2(_0185_),
    .B1_N(_0134_),
    .Y(_0187_));
 sky130_fd_sc_hd__a21oi_1 _1018_ (.A1(net101),
    .A2(_0184_),
    .B1(_0187_),
    .Y(_0188_));
 sky130_fd_sc_hd__nor3_2 _1019_ (.A(net9),
    .B(net96),
    .C(net97),
    .Y(_0189_));
 sky130_fd_sc_hd__and2_1 _1020_ (.A(net109),
    .B(net110),
    .X(_0190_));
 sky130_fd_sc_hd__nor2_1 _1021_ (.A(net105),
    .B(net112),
    .Y(_0191_));
 sky130_fd_sc_hd__and2b_1 _1024_ (.A_N(net100),
    .B(net104),
    .X(_0193_));
 sky130_fd_sc_hd__o211ai_1 _1025_ (.A1(_0190_),
    .A2(net88),
    .B1(_0193_),
    .C1(net113),
    .Y(_0194_));
 sky130_fd_sc_hd__o2111ai_1 _1026_ (.A1(net113),
    .A2(_0188_),
    .B1(net89),
    .C1(net115),
    .D1(_0194_),
    .Y(_0195_));
 sky130_fd_sc_hd__nand3_1 _1027_ (.A(_0180_),
    .B(_0183_),
    .C(_0195_),
    .Y(_0020_));
 sky130_fd_sc_hd__nand2_1 _1028_ (.A(net100),
    .B(_0138_),
    .Y(_0196_));
 sky130_fd_sc_hd__nor2_1 _1029_ (.A(net101),
    .B(net113),
    .Y(_0197_));
 sky130_fd_sc_hd__nor2_1 _1030_ (.A(_0796_),
    .B(_0197_),
    .Y(_0198_));
 sky130_fd_sc_hd__a21oi_1 _1031_ (.A1(net103),
    .A2(_0196_),
    .B1(_0198_),
    .Y(_0199_));
 sky130_fd_sc_hd__nor2b_1 _1034_ (.A(net113),
    .B_N(net101),
    .Y(_0201_));
 sky130_fd_sc_hd__nor2_1 _1035_ (.A(net102),
    .B(net112),
    .Y(_0202_));
 sky130_fd_sc_hd__o21ai_0 _1036_ (.A1(net115),
    .A2(_0201_),
    .B1(_0202_),
    .Y(_0203_));
 sky130_fd_sc_hd__a31oi_1 _1037_ (.A1(net107),
    .A2(_0199_),
    .A3(_0203_),
    .B1(_0153_),
    .Y(_0204_));
 sky130_fd_sc_hd__nand2b_1 _1038_ (.A_N(net113),
    .B(net112),
    .Y(_0205_));
 sky130_fd_sc_hd__nor2b_1 _1040_ (.A(net116),
    .B_N(net113),
    .Y(_0207_));
 sky130_fd_sc_hd__a21oi_1 _1042_ (.A1(net102),
    .A2(_0140_),
    .B1(_0207_),
    .Y(_0209_));
 sky130_fd_sc_hd__o22ai_1 _1043_ (.A1(net116),
    .A2(_0205_),
    .B1(_0209_),
    .B2(net111),
    .Y(_0210_));
 sky130_fd_sc_hd__a32oi_1 _1047_ (.A1(_0072_),
    .A2(net86),
    .A3(_0205_),
    .B1(net83),
    .B2(net104),
    .Y(_0213_));
 sky130_fd_sc_hd__a21oi_1 _1049_ (.A1(net94),
    .A2(net91),
    .B1(net87),
    .Y(_0215_));
 sky130_fd_sc_hd__nand2b_1 _1050_ (.A_N(net104),
    .B(net116),
    .Y(_0216_));
 sky130_fd_sc_hd__o221ai_1 _1052_ (.A1(net106),
    .A2(_0213_),
    .B1(_0215_),
    .B2(_0216_),
    .C1(net98),
    .Y(_0218_));
 sky130_fd_sc_hd__o21ai_0 _1053_ (.A1(net98),
    .A2(_0210_),
    .B1(_0218_),
    .Y(_0219_));
 sky130_fd_sc_hd__or2_0 _1058_ (.A(net99),
    .B(net103),
    .X(_0223_));
 sky130_fd_sc_hd__nor2_1 _1060_ (.A(net109),
    .B(_0223_),
    .Y(_0225_));
 sky130_fd_sc_hd__nand3_1 _1061_ (.A(net97),
    .B(net90),
    .C(_0225_),
    .Y(_0226_));
 sky130_fd_sc_hd__nor3_1 _1062_ (.A(net110),
    .B(net82),
    .C(_0226_),
    .Y(_0227_));
 sky130_fd_sc_hd__a211o_1 _1063_ (.A1(_0204_),
    .A2(_0219_),
    .B1(_0227_),
    .C1(_0031_),
    .X(_0022_));
 sky130_fd_sc_hd__inv_1 _1064_ (.A(net96),
    .Y(_0228_));
 sky130_fd_sc_hd__nor2_1 _1065_ (.A(_0228_),
    .B(_0060_),
    .Y(_0229_));
 sky130_fd_sc_hd__a31oi_1 _1067_ (.A1(_0190_),
    .A2(_0032_),
    .A3(_0229_),
    .B1(_0533_),
    .Y(_0030_));
 sky130_fd_sc_hd__o21ai_0 _1068_ (.A1(net108),
    .A2(_0144_),
    .B1(_0796_),
    .Y(_0230_));
 sky130_fd_sc_hd__nand2_1 _1069_ (.A(net108),
    .B(net99),
    .Y(_0231_));
 sky130_fd_sc_hd__nor2_1 _1071_ (.A(net99),
    .B(_0036_),
    .Y(_0233_));
 sky130_fd_sc_hd__nand2b_1 _1072_ (.A_N(net100),
    .B(net116),
    .Y(_0234_));
 sky130_fd_sc_hd__nand2b_1 _1073_ (.A_N(net116),
    .B(net100),
    .Y(_0235_));
 sky130_fd_sc_hd__a21oi_1 _1075_ (.A1(_0234_),
    .A2(_0235_),
    .B1(net106),
    .Y(_0237_));
 sky130_fd_sc_hd__o21ai_0 _1076_ (.A1(_0233_),
    .A2(_0237_),
    .B1(net112),
    .Y(_0238_));
 sky130_fd_sc_hd__o21ai_0 _1078_ (.A1(_0144_),
    .A2(_0231_),
    .B1(_0238_),
    .Y(_0239_));
 sky130_fd_sc_hd__o211ai_1 _1080_ (.A1(net99),
    .A2(_0144_),
    .B1(_0796_),
    .C1(net108),
    .Y(_0241_));
 sky130_fd_sc_hd__or2_2 _1081_ (.A(net115),
    .B(net112),
    .X(_0242_));
 sky130_fd_sc_hd__nand2_1 _1082_ (.A(net116),
    .B(net112),
    .Y(_0243_));
 sky130_fd_sc_hd__o211ai_1 _1083_ (.A1(net81),
    .A2(_0242_),
    .B1(_0243_),
    .C1(net94),
    .Y(_0244_));
 sky130_fd_sc_hd__nor2_1 _1084_ (.A(net107),
    .B(_0072_),
    .Y(_0245_));
 sky130_fd_sc_hd__a32oi_1 _1085_ (.A1(net113),
    .A2(_0241_),
    .A3(_0244_),
    .B1(_0245_),
    .B2(_0076_),
    .Y(_0246_));
 sky130_fd_sc_hd__nor2_1 _1086_ (.A(net103),
    .B(_0246_),
    .Y(_0247_));
 sky130_fd_sc_hd__a221oi_1 _1087_ (.A1(_0201_),
    .A2(_0230_),
    .B1(_0239_),
    .B2(net103),
    .C1(_0247_),
    .Y(_0248_));
 sky130_fd_sc_hd__and2_1 _1089_ (.A(net116),
    .B(net114),
    .X(_0249_));
 sky130_fd_sc_hd__nor2_4 _1091_ (.A(net115),
    .B(net113),
    .Y(_0251_));
 sky130_fd_sc_hd__a21oi_1 _1092_ (.A1(_0099_),
    .A2(_0249_),
    .B1(_0251_),
    .Y(_0252_));
 sky130_fd_sc_hd__o221ai_1 _1093_ (.A1(_0153_),
    .A2(_0248_),
    .B1(_0252_),
    .B2(_0226_),
    .C1(_0533_),
    .Y(_0019_));
 sky130_fd_sc_hd__a21oi_1 _1094_ (.A1(net106),
    .A2(net116),
    .B1(net114),
    .Y(_0253_));
 sky130_fd_sc_hd__a21oi_1 _1095_ (.A1(net114),
    .A2(_0243_),
    .B1(net102),
    .Y(_0254_));
 sky130_fd_sc_hd__o21ai_0 _1097_ (.A1(net87),
    .A2(_0254_),
    .B1(net94),
    .Y(_0256_));
 sky130_fd_sc_hd__and2_0 _1098_ (.A(net106),
    .B(net114),
    .X(_0257_));
 sky130_fd_sc_hd__nand2b_1 _1100_ (.A_N(net116),
    .B(net104),
    .Y(_0258_));
 sky130_fd_sc_hd__nand2_1 _1102_ (.A(_0257_),
    .B(_0258_),
    .Y(_0260_));
 sky130_fd_sc_hd__o2111ai_1 _1103_ (.A1(_0818_),
    .A2(_0253_),
    .B1(_0256_),
    .C1(_0260_),
    .D1(net100),
    .Y(_0261_));
 sky130_fd_sc_hd__nand2b_1 _1104_ (.A_N(net106),
    .B(net104),
    .Y(_0262_));
 sky130_fd_sc_hd__nand2_1 _1105_ (.A(_0072_),
    .B(_0076_),
    .Y(_0263_));
 sky130_fd_sc_hd__nor2b_1 _1106_ (.A(net104),
    .B_N(net3),
    .Y(_0264_));
 sky130_fd_sc_hd__o21ai_0 _1108_ (.A1(net82),
    .A2(_0264_),
    .B1(net106),
    .Y(_0266_));
 sky130_fd_sc_hd__nor2b_1 _1112_ (.A(net112),
    .B_N(net115),
    .Y(_0268_));
 sky130_fd_sc_hd__nor2b_1 _1113_ (.A(net104),
    .B_N(net114),
    .Y(_0269_));
 sky130_fd_sc_hd__o21ai_0 _1114_ (.A1(_0042_),
    .A2(_0268_),
    .B1(_0269_),
    .Y(_0270_));
 sky130_fd_sc_hd__o2111ai_1 _1115_ (.A1(_0262_),
    .A2(_0263_),
    .B1(_0266_),
    .C1(net81),
    .D1(_0270_),
    .Y(_0271_));
 sky130_fd_sc_hd__nor3_1 _1116_ (.A(net110),
    .B(_0070_),
    .C(_0038_),
    .Y(_0272_));
 sky130_fd_sc_hd__a21oi_1 _1117_ (.A1(_0261_),
    .A2(_0271_),
    .B1(_0272_),
    .Y(_0273_));
 sky130_fd_sc_hd__nor3_1 _1118_ (.A(net103),
    .B(net115),
    .C(net110),
    .Y(_0274_));
 sky130_fd_sc_hd__nand2_1 _1119_ (.A(net104),
    .B(net3),
    .Y(_0275_));
 sky130_fd_sc_hd__or2_1 _1120_ (.A(net104),
    .B(net116),
    .X(_0276_));
 sky130_fd_sc_hd__nor2b_1 _1122_ (.A(net114),
    .B_N(net3),
    .Y(_0672_));
 sky130_fd_sc_hd__a21oi_1 _1123_ (.A1(_0275_),
    .A2(_0276_),
    .B1(net94),
    .Y(_0278_));
 sky130_fd_sc_hd__o21ai_0 _1124_ (.A1(_0274_),
    .A2(_0278_),
    .B1(net113),
    .Y(_0279_));
 sky130_fd_sc_hd__nand2_1 _1125_ (.A(_0216_),
    .B(_0258_),
    .Y(_0280_));
 sky130_fd_sc_hd__nor2_1 _1126_ (.A(net107),
    .B(net113),
    .Y(_0281_));
 sky130_fd_sc_hd__nand2_1 _1127_ (.A(_0280_),
    .B(_0281_),
    .Y(_0282_));
 sky130_fd_sc_hd__inv_1 _1128_ (.A(net9),
    .Y(_0283_));
 sky130_fd_sc_hd__a21oi_1 _1129_ (.A1(_0511_),
    .A2(_0087_),
    .B1(_0283_),
    .Y(_0284_));
 sky130_fd_sc_hd__a31oi_1 _1130_ (.A1(_0115_),
    .A2(_0279_),
    .A3(_0282_),
    .B1(_0284_),
    .Y(_0285_));
 sky130_fd_sc_hd__o21ai_0 _1131_ (.A1(_0153_),
    .A2(_0273_),
    .B1(_0285_),
    .Y(_0028_));
 sky130_fd_sc_hd__nor2_1 _1132_ (.A(net106),
    .B(net81),
    .Y(_0286_));
 sky130_fd_sc_hd__nand2b_1 _1133_ (.A_N(net3),
    .B(net114),
    .Y(_0682_));
 sky130_fd_sc_hd__nor2_1 _1134_ (.A(net82),
    .B(_0207_),
    .Y(_0287_));
 sky130_fd_sc_hd__a221oi_1 _1135_ (.A1(_0063_),
    .A2(net87),
    .B1(_0286_),
    .B2(_0287_),
    .C1(_0703_),
    .Y(_0288_));
 sky130_fd_sc_hd__nor2_1 _1136_ (.A(net106),
    .B(net104),
    .Y(_0289_));
 sky130_fd_sc_hd__o21ai_0 _1138_ (.A1(net81),
    .A2(_0268_),
    .B1(net113),
    .Y(_0291_));
 sky130_fd_sc_hd__nand2_1 _1139_ (.A(net96),
    .B(_0060_),
    .Y(_0292_));
 sky130_fd_sc_hd__a31oi_1 _1140_ (.A1(_0205_),
    .A2(net85),
    .A3(_0291_),
    .B1(_0292_),
    .Y(_0293_));
 sky130_fd_sc_hd__nand2_1 _1141_ (.A(net98),
    .B(net116),
    .Y(_0294_));
 sky130_fd_sc_hd__a21oi_1 _1142_ (.A1(net104),
    .A2(net87),
    .B1(_0269_),
    .Y(_0295_));
 sky130_fd_sc_hd__o32ai_1 _1143_ (.A1(net114),
    .A2(_0796_),
    .A3(_0032_),
    .B1(_0294_),
    .B2(_0295_),
    .Y(_0296_));
 sky130_fd_sc_hd__a21oi_1 _1145_ (.A1(net102),
    .A2(_0207_),
    .B1(net95),
    .Y(_0297_));
 sky130_fd_sc_hd__nor2_1 _1146_ (.A(net111),
    .B(_0297_),
    .Y(_0298_));
 sky130_fd_sc_hd__o21ai_0 _1148_ (.A1(_0296_),
    .A2(_0298_),
    .B1(net106),
    .Y(_0300_));
 sky130_fd_sc_hd__o211ai_1 _1149_ (.A1(net92),
    .A2(_0288_),
    .B1(_0293_),
    .C1(_0300_),
    .Y(_0301_));
 sky130_fd_sc_hd__a21oi_1 _1151_ (.A1(_0249_),
    .A2(_0264_),
    .B1(_0076_),
    .Y(_0303_));
 sky130_fd_sc_hd__nor2_1 _1152_ (.A(net104),
    .B(net116),
    .Y(_0304_));
 sky130_fd_sc_hd__o31a_1 _1153_ (.A1(net98),
    .A2(_0304_),
    .A3(_0173_),
    .B1(_0258_),
    .X(_0305_));
 sky130_fd_sc_hd__o22ai_1 _1154_ (.A1(net92),
    .A2(_0036_),
    .B1(_0276_),
    .B2(net98),
    .Y(_0306_));
 sky130_fd_sc_hd__nor2_1 _1155_ (.A(net99),
    .B(net86),
    .Y(_0703_));
 sky130_fd_sc_hd__nand2_1 _1156_ (.A(net3),
    .B(_0306_),
    .Y(_0307_));
 sky130_fd_sc_hd__o221ai_1 _1157_ (.A1(net81),
    .A2(_0303_),
    .B1(_0305_),
    .B2(net3),
    .C1(_0307_),
    .Y(_0308_));
 sky130_fd_sc_hd__nand2_1 _1158_ (.A(net104),
    .B(net114),
    .Y(_0309_));
 sky130_fd_sc_hd__nand2_1 _1159_ (.A(net116),
    .B(_0309_),
    .Y(_0310_));
 sky130_fd_sc_hd__nor3b_1 _1160_ (.A(net98),
    .B(net116),
    .C_N(net114),
    .Y(_0311_));
 sky130_fd_sc_hd__a21oi_1 _1161_ (.A1(net98),
    .A2(net116),
    .B1(_0311_),
    .Y(_0312_));
 sky130_fd_sc_hd__o21ai_0 _1162_ (.A1(_0249_),
    .A2(_0264_),
    .B1(net98),
    .Y(_0313_));
 sky130_fd_sc_hd__o221ai_1 _1163_ (.A1(net98),
    .A2(_0310_),
    .B1(_0312_),
    .B2(net92),
    .C1(_0313_),
    .Y(_0314_));
 sky130_fd_sc_hd__nand2_1 _1164_ (.A(net96),
    .B(net97),
    .Y(_0315_));
 sky130_fd_sc_hd__a21oi_1 _1165_ (.A1(net105),
    .A2(_0314_),
    .B1(_0315_),
    .Y(_0316_));
 sky130_fd_sc_hd__a21oi_1 _1166_ (.A1(net99),
    .A2(net87),
    .B1(_0703_),
    .Y(_0713_));
 sky130_fd_sc_hd__o21ai_0 _1167_ (.A1(net105),
    .A2(_0308_),
    .B1(_0316_),
    .Y(_0317_));
 sky130_fd_sc_hd__nand2_1 _1168_ (.A(net97),
    .B(net81),
    .Y(_0318_));
 sky130_fd_sc_hd__a21oi_1 _1169_ (.A1(_0117_),
    .A2(net88),
    .B1(net92),
    .Y(_0319_));
 sky130_fd_sc_hd__o22ai_1 _1170_ (.A1(net97),
    .A2(_0470_),
    .B1(_0318_),
    .B2(_0319_),
    .Y(_0320_));
 sky130_fd_sc_hd__o21ai_1 _1171_ (.A1(_0257_),
    .A2(_0264_),
    .B1(net115),
    .Y(_0321_));
 sky130_fd_sc_hd__nor2_1 _1172_ (.A(net104),
    .B(_0068_),
    .Y(_0322_));
 sky130_fd_sc_hd__a221oi_1 _1173_ (.A1(net108),
    .A2(_0818_),
    .B1(_0173_),
    .B2(net88),
    .C1(_0322_),
    .Y(_0323_));
 sky130_fd_sc_hd__nand2_1 _1174_ (.A(net97),
    .B(net6),
    .Y(_0324_));
 sky130_fd_sc_hd__a21oi_1 _1175_ (.A1(_0321_),
    .A2(_0323_),
    .B1(_0324_),
    .Y(_0325_));
 sky130_fd_sc_hd__or3_1 _1176_ (.A(net96),
    .B(_0320_),
    .C(_0325_),
    .X(_0326_));
 sky130_fd_sc_hd__inv_1 _1178_ (.A(net88),
    .Y(_0327_));
 sky130_fd_sc_hd__a21oi_1 _1179_ (.A1(net98),
    .A2(net82),
    .B1(_0311_),
    .Y(_0328_));
 sky130_fd_sc_hd__nor2b_1 _1180_ (.A(net100),
    .B_N(net116),
    .Y(_0329_));
 sky130_fd_sc_hd__a21oi_1 _1181_ (.A1(net100),
    .A2(_0207_),
    .B1(_0329_),
    .Y(_0330_));
 sky130_fd_sc_hd__nor4_1 _1182_ (.A(net98),
    .B(net116),
    .C(net114),
    .D(net111),
    .Y(_0331_));
 sky130_fd_sc_hd__o21ai_1 _1183_ (.A1(net83),
    .A2(_0331_),
    .B1(net105),
    .Y(_0332_));
 sky130_fd_sc_hd__o221ai_1 _1184_ (.A1(_0327_),
    .A2(_0328_),
    .B1(_0330_),
    .B2(_0099_),
    .C1(_0332_),
    .Y(_0333_));
 sky130_fd_sc_hd__o21ai_0 _1185_ (.A1(_0046_),
    .A2(net82),
    .B1(net106),
    .Y(_0334_));
 sky130_fd_sc_hd__nand2b_1 _1186_ (.A_N(net102),
    .B(net98),
    .Y(_0335_));
 sky130_fd_sc_hd__a21oi_1 _1187_ (.A1(_0263_),
    .A2(_0334_),
    .B1(_0335_),
    .Y(_0336_));
 sky130_fd_sc_hd__nand2b_1 _1189_ (.A_N(net115),
    .B(net106),
    .Y(_0337_));
 sky130_fd_sc_hd__a2bb2oi_1 _1190_ (.A1_N(_0068_),
    .A2_N(_0337_),
    .B1(_0268_),
    .B2(net92),
    .Y(_0338_));
 sky130_fd_sc_hd__nand2_1 _1191_ (.A(net94),
    .B(_0249_),
    .Y(_0339_));
 sky130_fd_sc_hd__o22ai_1 _1192_ (.A1(net98),
    .A2(_0338_),
    .B1(_0339_),
    .B2(net104),
    .Y(_0340_));
 sky130_fd_sc_hd__a211oi_1 _1193_ (.A1(net104),
    .A2(_0333_),
    .B1(_0336_),
    .C1(_0340_),
    .Y(_0341_));
 sky130_fd_sc_hd__o32ai_1 _1194_ (.A1(net110),
    .A2(net82),
    .A3(_0226_),
    .B1(_0341_),
    .B2(_0153_),
    .Y(_0342_));
 sky130_fd_sc_hd__a41o_1 _1195_ (.A1(net9),
    .A2(_0301_),
    .A3(_0317_),
    .A4(_0326_),
    .B1(_0342_),
    .X(_0007_));
 sky130_fd_sc_hd__o21ai_0 _1196_ (.A1(net103),
    .A2(_0117_),
    .B1(_0044_),
    .Y(_0343_));
 sky130_fd_sc_hd__nor4_1 _1197_ (.A(net101),
    .B(net110),
    .C(_0249_),
    .D(_0173_),
    .Y(_0345_));
 sky130_fd_sc_hd__a211oi_1 _1198_ (.A1(net101),
    .A2(_0343_),
    .B1(_0345_),
    .C1(net109),
    .Y(_0346_));
 sky130_fd_sc_hd__nand2_1 _1200_ (.A(net99),
    .B(net112),
    .Y(_0347_));
 sky130_fd_sc_hd__nor2_1 _1201_ (.A(net92),
    .B(_0117_),
    .Y(_0348_));
 sky130_fd_sc_hd__nor2_1 _1202_ (.A(_0064_),
    .B(_0348_),
    .Y(_0349_));
 sky130_fd_sc_hd__nand2_1 _1203_ (.A(net95),
    .B(_0251_),
    .Y(_0350_));
 sky130_fd_sc_hd__a21oi_1 _1204_ (.A1(_0242_),
    .A2(_0036_),
    .B1(net101),
    .Y(_0351_));
 sky130_fd_sc_hd__nor3b_2 _1205_ (.A(net113),
    .B(net110),
    .C_N(net115),
    .Y(_0352_));
 sky130_fd_sc_hd__o21ai_0 _1206_ (.A1(_0351_),
    .A2(_0352_),
    .B1(net103),
    .Y(_0353_));
 sky130_fd_sc_hd__o2111a_1 _1207_ (.A1(_0347_),
    .A2(_0349_),
    .B1(_0350_),
    .C1(_0353_),
    .D1(net109),
    .X(_0354_));
 sky130_fd_sc_hd__o221ai_1 _1208_ (.A1(_0223_),
    .A2(_0106_),
    .B1(_0346_),
    .B2(_0354_),
    .C1(_0060_),
    .Y(_0356_));
 sky130_fd_sc_hd__nand2_1 _1209_ (.A(net97),
    .B(_0074_),
    .Y(_0357_));
 sky130_fd_sc_hd__nor2_1 _1211_ (.A(net86),
    .B(_0226_),
    .Y(_0358_));
 sky130_fd_sc_hd__a311o_1 _1212_ (.A1(net90),
    .A2(_0356_),
    .A3(_0357_),
    .B1(_0358_),
    .C1(_0091_),
    .X(_0003_));
 sky130_fd_sc_hd__a21oi_1 _1214_ (.A1(net115),
    .A2(net86),
    .B1(_0070_),
    .Y(_0360_));
 sky130_fd_sc_hd__nor3b_1 _1215_ (.A(net116),
    .B(net3),
    .C_N(net114),
    .Y(_0361_));
 sky130_fd_sc_hd__o21a_1 _1216_ (.A1(net87),
    .A2(net84),
    .B1(net85),
    .X(_0362_));
 sky130_fd_sc_hd__o21ai_0 _1217_ (.A1(_0360_),
    .A2(_0362_),
    .B1(net99),
    .Y(_0363_));
 sky130_fd_sc_hd__nand2_1 _1218_ (.A(net99),
    .B(net91),
    .Y(_0364_));
 sky130_fd_sc_hd__a21boi_0 _1219_ (.A1(net81),
    .A2(_0064_),
    .B1_N(_0364_),
    .Y(_0366_));
 sky130_fd_sc_hd__o21ai_0 _1220_ (.A1(net81),
    .A2(_0269_),
    .B1(_0818_),
    .Y(_0367_));
 sky130_fd_sc_hd__a221oi_1 _1223_ (.A1(net81),
    .A2(net83),
    .B1(_0367_),
    .B2(net107),
    .C1(_0072_),
    .Y(_0368_));
 sky130_fd_sc_hd__o21ai_0 _1224_ (.A1(net107),
    .A2(_0366_),
    .B1(_0368_),
    .Y(_0369_));
 sky130_fd_sc_hd__o2111ai_1 _1225_ (.A1(_0114_),
    .A2(_0276_),
    .B1(_0363_),
    .C1(_0369_),
    .D1(_0060_),
    .Y(_0370_));
 sky130_fd_sc_hd__a21oi_1 _1226_ (.A1(net116),
    .A2(_0185_),
    .B1(_0159_),
    .Y(_0371_));
 sky130_fd_sc_hd__a31oi_1 _1227_ (.A1(net114),
    .A2(_0275_),
    .A3(_0329_),
    .B1(_0371_),
    .Y(_0372_));
 sky130_fd_sc_hd__o22ai_1 _1228_ (.A1(net112),
    .A2(_0223_),
    .B1(_0068_),
    .B2(net115),
    .Y(_0373_));
 sky130_fd_sc_hd__nor2_1 _1229_ (.A(net99),
    .B(_0202_),
    .Y(_0374_));
 sky130_fd_sc_hd__o21ai_0 _1230_ (.A1(net115),
    .A2(_0374_),
    .B1(net97),
    .Y(_0375_));
 sky130_fd_sc_hd__a21oi_1 _1231_ (.A1(net108),
    .A2(_0373_),
    .B1(_0375_),
    .Y(_0377_));
 sky130_fd_sc_hd__o21ai_0 _1232_ (.A1(net108),
    .A2(_0372_),
    .B1(_0377_),
    .Y(_0378_));
 sky130_fd_sc_hd__a31o_2 _1234_ (.A1(net90),
    .A2(_0370_),
    .A3(_0378_),
    .B1(_0091_),
    .X(_0001_));
 sky130_fd_sc_hd__o21ai_0 _1235_ (.A1(_0068_),
    .A2(_0070_),
    .B1(_0115_),
    .Y(_0379_));
 sky130_fd_sc_hd__and3_1 _1236_ (.A(_0138_),
    .B(_0242_),
    .C(net85),
    .X(_0380_));
 sky130_fd_sc_hd__xnor2_1 _1237_ (.A(net81),
    .B(_0251_),
    .Y(_0381_));
 sky130_fd_sc_hd__a221oi_1 _1238_ (.A1(net95),
    .A2(net82),
    .B1(_0381_),
    .B2(net103),
    .C1(net94),
    .Y(_0382_));
 sky130_fd_sc_hd__o21ai_0 _1239_ (.A1(net103),
    .A2(_0038_),
    .B1(_0159_),
    .Y(_0383_));
 sky130_fd_sc_hd__a221oi_1 _1240_ (.A1(net95),
    .A2(_0251_),
    .B1(_0383_),
    .B2(net101),
    .C1(net107),
    .Y(_0384_));
 sky130_fd_sc_hd__nand2b_1 _1241_ (.A_N(net104),
    .B(net114),
    .Y(_0385_));
 sky130_fd_sc_hd__nand2_1 _1242_ (.A(_0223_),
    .B(_0281_),
    .Y(_0387_));
 sky130_fd_sc_hd__o21ai_0 _1243_ (.A1(net94),
    .A2(_0385_),
    .B1(_0387_),
    .Y(_0388_));
 sky130_fd_sc_hd__a21oi_1 _1245_ (.A1(_0046_),
    .A2(_0388_),
    .B1(_0153_),
    .Y(_0389_));
 sky130_fd_sc_hd__o31ai_1 _1246_ (.A1(_0099_),
    .A2(_0382_),
    .A3(_0384_),
    .B1(_0389_),
    .Y(_0390_));
 sky130_fd_sc_hd__o211ai_1 _1247_ (.A1(_0379_),
    .A2(_0380_),
    .B1(_0390_),
    .C1(_0093_),
    .Y(_0004_));
 sky130_fd_sc_hd__o21ai_0 _1248_ (.A1(net102),
    .A2(_0038_),
    .B1(_0036_),
    .Y(_0391_));
 sky130_fd_sc_hd__a22oi_1 _1249_ (.A1(net91),
    .A2(_0112_),
    .B1(_0391_),
    .B2(net111),
    .Y(_0392_));
 sky130_fd_sc_hd__nor2_1 _1250_ (.A(net99),
    .B(_0392_),
    .Y(_0393_));
 sky130_fd_sc_hd__nor3_1 _1251_ (.A(net102),
    .B(_0038_),
    .C(_0040_),
    .Y(_0394_));
 sky130_fd_sc_hd__a21oi_1 _1252_ (.A1(net92),
    .A2(_0235_),
    .B1(net112),
    .Y(_0395_));
 sky130_fd_sc_hd__a31oi_1 _1253_ (.A1(net102),
    .A2(_0234_),
    .A3(_0235_),
    .B1(_0395_),
    .Y(_0397_));
 sky130_fd_sc_hd__o221ai_1 _1254_ (.A1(_0385_),
    .A2(_0347_),
    .B1(_0397_),
    .B2(net114),
    .C1(net94),
    .Y(_0398_));
 sky130_fd_sc_hd__nand2b_1 _1255_ (.A_N(net116),
    .B(net3),
    .Y(_0796_));
 sky130_fd_sc_hd__o311ai_1 _1256_ (.A1(net94),
    .A2(_0393_),
    .A3(_0394_),
    .B1(_0060_),
    .C1(_0398_),
    .Y(_0399_));
 sky130_fd_sc_hd__o21ai_0 _1257_ (.A1(_0257_),
    .A2(net82),
    .B1(net110),
    .Y(_0400_));
 sky130_fd_sc_hd__nand2b_1 _1258_ (.A_N(net98),
    .B(net104),
    .Y(_0401_));
 sky130_fd_sc_hd__a21oi_1 _1259_ (.A1(_0249_),
    .A2(net88),
    .B1(_0401_),
    .Y(_0402_));
 sky130_fd_sc_hd__a21oi_1 _1260_ (.A1(_0400_),
    .A2(_0402_),
    .B1(_0060_),
    .Y(_0403_));
 sky130_fd_sc_hd__nor2b_1 _1261_ (.A(net117),
    .B_N(net6),
    .Y(_0404_));
 sky130_fd_sc_hd__nand2_1 _1262_ (.A(_0068_),
    .B(net85),
    .Y(_0405_));
 sky130_fd_sc_hd__o21ai_0 _1263_ (.A1(net4),
    .A2(net83),
    .B1(net102),
    .Y(_0406_));
 sky130_fd_sc_hd__nand3_1 _1264_ (.A(_0404_),
    .B(_0405_),
    .C(_0406_),
    .Y(_0408_));
 sky130_fd_sc_hd__and3b_1 _1265_ (.A_N(net107),
    .B(net115),
    .C(net113),
    .X(_0409_));
 sky130_fd_sc_hd__a21oi_1 _1267_ (.A1(net109),
    .A2(_0039_),
    .B1(_0409_),
    .Y(_0410_));
 sky130_fd_sc_hd__o221ai_1 _1268_ (.A1(_0082_),
    .A2(_0205_),
    .B1(_0410_),
    .B2(net110),
    .C1(net95),
    .Y(_0411_));
 sky130_fd_sc_hd__nand3_1 _1269_ (.A(_0403_),
    .B(_0408_),
    .C(_0411_),
    .Y(_0412_));
 sky130_fd_sc_hd__o21ai_0 _1270_ (.A1(net92),
    .A2(_0086_),
    .B1(net101),
    .Y(_0413_));
 sky130_fd_sc_hd__o21ai_1 _1271_ (.A1(net117),
    .A2(net113),
    .B1(net110),
    .Y(_0414_));
 sky130_fd_sc_hd__nand2_1 _1272_ (.A(_0414_),
    .B(net85),
    .Y(_0415_));
 sky130_fd_sc_hd__nand3_1 _1273_ (.A(_0229_),
    .B(_0413_),
    .C(_0415_),
    .Y(_0416_));
 sky130_fd_sc_hd__a32o_1 _1274_ (.A1(net90),
    .A2(_0399_),
    .A3(_0412_),
    .B1(_0416_),
    .B2(_0284_),
    .X(_0025_));
 sky130_fd_sc_hd__nand2_1 _1275_ (.A(net99),
    .B(net113),
    .Y(_0418_));
 sky130_fd_sc_hd__nor2_1 _1276_ (.A(_0112_),
    .B(_0418_),
    .Y(_0419_));
 sky130_fd_sc_hd__nand2b_1 _1277_ (.A_N(net3),
    .B(net104),
    .Y(_0818_));
 sky130_fd_sc_hd__nand2_1 _1278_ (.A(net101),
    .B(net82),
    .Y(_0420_));
 sky130_fd_sc_hd__a21oi_1 _1279_ (.A1(_0128_),
    .A2(_0420_),
    .B1(net103),
    .Y(_0421_));
 sky130_fd_sc_hd__a21oi_1 _1280_ (.A1(net103),
    .A2(_0117_),
    .B1(_0251_),
    .Y(_0422_));
 sky130_fd_sc_hd__o21ai_0 _1281_ (.A1(net101),
    .A2(_0422_),
    .B1(net109),
    .Y(_0423_));
 sky130_fd_sc_hd__o31a_1 _1282_ (.A1(net109),
    .A2(_0419_),
    .A3(_0421_),
    .B1(_0423_),
    .X(_0424_));
 sky130_fd_sc_hd__nand2_1 _1283_ (.A(net94),
    .B(net81),
    .Y(_0425_));
 sky130_fd_sc_hd__nor2_1 _1284_ (.A(net103),
    .B(net93),
    .Y(_0426_));
 sky130_fd_sc_hd__nor2_1 _1285_ (.A(_0348_),
    .B(_0426_),
    .Y(_0427_));
 sky130_fd_sc_hd__o221ai_1 _1286_ (.A1(_0425_),
    .A2(_0287_),
    .B1(_0231_),
    .B2(_0427_),
    .C1(net111),
    .Y(_0429_));
 sky130_fd_sc_hd__o211ai_1 _1287_ (.A1(net110),
    .A2(_0424_),
    .B1(_0429_),
    .C1(net89),
    .Y(_0430_));
 sky130_fd_sc_hd__o311ai_1 _1289_ (.A1(net110),
    .A2(_0117_),
    .A3(_0226_),
    .B1(_0430_),
    .C1(_0533_),
    .Y(_0015_));
 sky130_fd_sc_hd__o21ai_0 _1290_ (.A1(_0070_),
    .A2(_0144_),
    .B1(net89),
    .Y(_0431_));
 sky130_fd_sc_hd__or2_4 _1291_ (.A(net114),
    .B(net3),
    .X(_0432_));
 sky130_fd_sc_hd__o22ai_1 _1293_ (.A1(net116),
    .A2(_0068_),
    .B1(_0216_),
    .B2(_0432_),
    .Y(_0434_));
 sky130_fd_sc_hd__a21oi_1 _1294_ (.A1(_0099_),
    .A2(_0249_),
    .B1(_0304_),
    .Y(_0435_));
 sky130_fd_sc_hd__o22ai_1 _1295_ (.A1(_0432_),
    .A2(_0258_),
    .B1(_0435_),
    .B2(net98),
    .Y(_0436_));
 sky130_fd_sc_hd__a21oi_1 _1296_ (.A1(net98),
    .A2(_0434_),
    .B1(_0436_),
    .Y(_0437_));
 sky130_fd_sc_hd__nand2_1 _1297_ (.A(net104),
    .B(net91),
    .Y(_0439_));
 sky130_fd_sc_hd__o21ai_0 _1298_ (.A1(net104),
    .A2(_0036_),
    .B1(_0439_),
    .Y(_0440_));
 sky130_fd_sc_hd__a21oi_1 _1299_ (.A1(_0796_),
    .A2(_0818_),
    .B1(net99),
    .Y(_0839_));
 sky130_fd_sc_hd__a21oi_1 _1300_ (.A1(net104),
    .A2(net87),
    .B1(_0202_),
    .Y(_0441_));
 sky130_fd_sc_hd__nor2_1 _1301_ (.A(net116),
    .B(_0441_),
    .Y(_0442_));
 sky130_fd_sc_hd__a21oi_1 _1302_ (.A1(net106),
    .A2(_0440_),
    .B1(_0442_),
    .Y(_0443_));
 sky130_fd_sc_hd__nand2b_1 _1303_ (.A_N(net110),
    .B(net109),
    .Y(_0444_));
 sky130_fd_sc_hd__o32ai_1 _1305_ (.A1(_0064_),
    .A2(_0207_),
    .A3(_0444_),
    .B1(_0287_),
    .B2(_0275_),
    .Y(_0446_));
 sky130_fd_sc_hd__nand2_1 _1306_ (.A(net100),
    .B(_0446_),
    .Y(_0447_));
 sky130_fd_sc_hd__o221ai_1 _1307_ (.A1(net106),
    .A2(_0437_),
    .B1(_0443_),
    .B2(net100),
    .C1(_0447_),
    .Y(_0448_));
 sky130_fd_sc_hd__nor2_1 _1308_ (.A(_0315_),
    .B(_0335_),
    .Y(_0450_));
 sky130_fd_sc_hd__nand3_1 _1309_ (.A(net96),
    .B(net97),
    .C(net101),
    .Y(_0451_));
 sky130_fd_sc_hd__a21oi_1 _1310_ (.A1(net99),
    .A2(net115),
    .B1(_0839_),
    .Y(_0850_));
 sky130_fd_sc_hd__nand2_1 _1311_ (.A(net92),
    .B(_0511_),
    .Y(_0452_));
 sky130_fd_sc_hd__a21oi_1 _1312_ (.A1(_0451_),
    .A2(_0452_),
    .B1(_0190_),
    .Y(_0453_));
 sky130_fd_sc_hd__a2111oi_0 _1313_ (.A1(net81),
    .A2(_0511_),
    .B1(_0450_),
    .C1(_0453_),
    .D1(_0283_),
    .Y(_0454_));
 sky130_fd_sc_hd__nor3_1 _1314_ (.A(net83),
    .B(net82),
    .C(_0226_),
    .Y(_0455_));
 sky130_fd_sc_hd__nor2_1 _1315_ (.A(_0454_),
    .B(_0455_),
    .Y(_0456_));
 sky130_fd_sc_hd__o21ai_0 _1316_ (.A1(_0431_),
    .A2(_0448_),
    .B1(_0456_),
    .Y(_0014_));
 sky130_fd_sc_hd__nor2_1 _1317_ (.A(net107),
    .B(_0818_),
    .Y(_0457_));
 sky130_fd_sc_hd__a21oi_1 _1318_ (.A1(net110),
    .A2(_0112_),
    .B1(_0457_),
    .Y(_0458_));
 sky130_fd_sc_hd__a21oi_1 _1319_ (.A1(net92),
    .A2(_0068_),
    .B1(net115),
    .Y(_0460_));
 sky130_fd_sc_hd__nand2_1 _1320_ (.A(net102),
    .B(net115),
    .Y(_0461_));
 sky130_fd_sc_hd__nor2_1 _1322_ (.A(net99),
    .B(_0461_),
    .Y(_0462_));
 sky130_fd_sc_hd__a21oi_1 _1323_ (.A1(net99),
    .A2(_0460_),
    .B1(_0462_),
    .Y(_0463_));
 sky130_fd_sc_hd__o221ai_1 _1324_ (.A1(net99),
    .A2(_0458_),
    .B1(_0463_),
    .B2(net107),
    .C1(net89),
    .Y(_0464_));
 sky130_fd_sc_hd__a22oi_1 _1325_ (.A1(_0038_),
    .A2(_0286_),
    .B1(_0234_),
    .B2(_0257_),
    .Y(_0465_));
 sky130_fd_sc_hd__and2_1 _1326_ (.A(net104),
    .B(net115),
    .X(_0466_));
 sky130_fd_sc_hd__a2bb2oi_1 _1327_ (.A1_N(net102),
    .A2_N(_0465_),
    .B1(_0466_),
    .B2(net106),
    .Y(_0467_));
 sky130_fd_sc_hd__nor2_1 _1328_ (.A(net104),
    .B(_0133_),
    .Y(_0468_));
 sky130_fd_sc_hd__a21oi_1 _1329_ (.A1(net104),
    .A2(net112),
    .B1(_0329_),
    .Y(_0469_));
 sky130_fd_sc_hd__o22ai_1 _1330_ (.A1(_0231_),
    .A2(_0468_),
    .B1(_0469_),
    .B2(net106),
    .Y(_0471_));
 sky130_fd_sc_hd__a21oi_1 _1331_ (.A1(net81),
    .A2(_0042_),
    .B1(_0471_),
    .Y(_0472_));
 sky130_fd_sc_hd__o22ai_1 _1334_ (.A1(net112),
    .A2(_0467_),
    .B1(_0472_),
    .B2(net114),
    .Y(_0473_));
 sky130_fd_sc_hd__nand2_1 _1335_ (.A(net110),
    .B(_0182_),
    .Y(_0474_));
 sky130_fd_sc_hd__o211ai_1 _1336_ (.A1(_0464_),
    .A2(_0473_),
    .B1(_0474_),
    .C1(_0533_),
    .Y(_0017_));
 sky130_fd_sc_hd__nor3_1 _1337_ (.A(net109),
    .B(net82),
    .C(net84),
    .Y(_0475_));
 sky130_fd_sc_hd__a31oi_1 _1338_ (.A1(net109),
    .A2(net93),
    .A3(_0106_),
    .B1(_0475_),
    .Y(_0476_));
 sky130_fd_sc_hd__o21ai_0 _1339_ (.A1(net101),
    .A2(_0068_),
    .B1(_0432_),
    .Y(_0477_));
 sky130_fd_sc_hd__a221oi_1 _1340_ (.A1(net101),
    .A2(_0476_),
    .B1(_0477_),
    .B2(_0245_),
    .C1(net103),
    .Y(_0478_));
 sky130_fd_sc_hd__a21oi_1 _1341_ (.A1(net107),
    .A2(_0207_),
    .B1(_0281_),
    .Y(_0479_));
 sky130_fd_sc_hd__o22ai_1 _1342_ (.A1(_0039_),
    .A2(_0444_),
    .B1(_0479_),
    .B2(_0099_),
    .Y(_0481_));
 sky130_fd_sc_hd__a22oi_1 _1343_ (.A1(net110),
    .A2(_0251_),
    .B1(_0249_),
    .B2(net101),
    .Y(_0482_));
 sky130_fd_sc_hd__o21ai_0 _1345_ (.A1(net109),
    .A2(_0482_),
    .B1(net103),
    .Y(_0483_));
 sky130_fd_sc_hd__a21oi_1 _1346_ (.A1(net81),
    .A2(_0481_),
    .B1(_0483_),
    .Y(_0484_));
 sky130_fd_sc_hd__o31ai_1 _1347_ (.A1(_0153_),
    .A2(_0478_),
    .A3(_0484_),
    .B1(_0183_),
    .Y(_0016_));
 sky130_fd_sc_hd__nand3_1 _1348_ (.A(net92),
    .B(_0115_),
    .C(net88),
    .Y(_0485_));
 sky130_fd_sc_hd__nand2_1 _1349_ (.A(net94),
    .B(_0414_),
    .Y(_0486_));
 sky130_fd_sc_hd__a22oi_1 _1350_ (.A1(net103),
    .A2(_0122_),
    .B1(_0486_),
    .B2(net81),
    .Y(_0487_));
 sky130_fd_sc_hd__o21ai_0 _1351_ (.A1(_0315_),
    .A2(_0487_),
    .B1(_0031_),
    .Y(_0488_));
 sky130_fd_sc_hd__nand3_1 _1352_ (.A(_0040_),
    .B(_0262_),
    .C(_0185_),
    .Y(_0489_));
 sky130_fd_sc_hd__nor2_1 _1353_ (.A(net99),
    .B(_0275_),
    .Y(_0491_));
 sky130_fd_sc_hd__o21ai_0 _1354_ (.A1(net115),
    .A2(_0491_),
    .B1(net94),
    .Y(_0492_));
 sky130_fd_sc_hd__o2111ai_1 _1356_ (.A1(net94),
    .A2(_0276_),
    .B1(_0461_),
    .C1(_0489_),
    .D1(_0492_),
    .Y(_0493_));
 sky130_fd_sc_hd__nand2_1 _1357_ (.A(net104),
    .B(_0133_),
    .Y(_0494_));
 sky130_fd_sc_hd__nor2b_1 _1358_ (.A(net103),
    .B_N(net99),
    .Y(_0495_));
 sky130_fd_sc_hd__a221oi_1 _1359_ (.A1(_0268_),
    .A2(_0193_),
    .B1(_0495_),
    .B2(_0042_),
    .C1(net106),
    .Y(_0496_));
 sky130_fd_sc_hd__a31oi_1 _1360_ (.A1(net106),
    .A2(_0137_),
    .A3(_0494_),
    .B1(_0496_),
    .Y(_0497_));
 sky130_fd_sc_hd__o21ai_0 _1361_ (.A1(_0231_),
    .A2(_0494_),
    .B1(net89),
    .Y(_0498_));
 sky130_fd_sc_hd__a21oi_1 _1362_ (.A1(net114),
    .A2(_0497_),
    .B1(_0498_),
    .Y(_0499_));
 sky130_fd_sc_hd__o21ai_0 _1363_ (.A1(net114),
    .A2(_0493_),
    .B1(_0499_),
    .Y(_0500_));
 sky130_fd_sc_hd__o211ai_1 _1364_ (.A1(_0039_),
    .A2(_0485_),
    .B1(_0488_),
    .C1(_0500_),
    .Y(_0013_));
 sky130_fd_sc_hd__nand3_1 _1365_ (.A(net97),
    .B(net6),
    .C(net102),
    .Y(_0502_));
 sky130_fd_sc_hd__a21o_1 _1367_ (.A1(net117),
    .A2(net113),
    .B1(net110),
    .X(_0503_));
 sky130_fd_sc_hd__nand2_1 _1368_ (.A(net4),
    .B(_0503_),
    .Y(_0504_));
 sky130_fd_sc_hd__nor2_1 _1369_ (.A(_0502_),
    .B(_0504_),
    .Y(_0505_));
 sky130_fd_sc_hd__a21oi_1 _1370_ (.A1(net6),
    .A2(_0459_),
    .B1(net97),
    .Y(_0506_));
 sky130_fd_sc_hd__nor2_1 _1371_ (.A(net96),
    .B(_0506_),
    .Y(_0507_));
 sky130_fd_sc_hd__nand3b_1 _1372_ (.A_N(_0505_),
    .B(_0507_),
    .C(net9),
    .Y(_0508_));
 sky130_fd_sc_hd__o21ai_0 _1373_ (.A1(net99),
    .A2(_0216_),
    .B1(_0364_),
    .Y(_0509_));
 sky130_fd_sc_hd__nand2_1 _1374_ (.A(net99),
    .B(_0264_),
    .Y(_0510_));
 sky130_fd_sc_hd__o21ai_0 _1375_ (.A1(_0425_),
    .A2(_0144_),
    .B1(_0510_),
    .Y(_0512_));
 sky130_fd_sc_hd__o32ai_1 _1376_ (.A1(_0072_),
    .A2(_0223_),
    .A3(net87),
    .B1(_0231_),
    .B2(_0068_),
    .Y(_0513_));
 sky130_fd_sc_hd__a221o_1 _1378_ (.A1(net94),
    .A2(_0509_),
    .B1(_0512_),
    .B2(_0138_),
    .C1(_0513_),
    .X(_0514_));
 sky130_fd_sc_hd__nand3_1 _1379_ (.A(net100),
    .B(net104),
    .C(net3),
    .Y(_0515_));
 sky130_fd_sc_hd__nor2_1 _1380_ (.A(net81),
    .B(_0138_),
    .Y(_0516_));
 sky130_fd_sc_hd__a221o_1 _1381_ (.A1(net102),
    .A2(net83),
    .B1(_0064_),
    .B2(net99),
    .C1(net106),
    .X(_0517_));
 sky130_fd_sc_hd__o31ai_1 _1382_ (.A1(net94),
    .A2(_0264_),
    .A3(_0516_),
    .B1(_0517_),
    .Y(_0518_));
 sky130_fd_sc_hd__a21oi_1 _1383_ (.A1(_0515_),
    .A2(_0518_),
    .B1(net115),
    .Y(_0519_));
 sky130_fd_sc_hd__o21ai_1 _1384_ (.A1(_0514_),
    .A2(_0519_),
    .B1(net89),
    .Y(_0520_));
 sky130_fd_sc_hd__o21ai_0 _1385_ (.A1(_0196_),
    .A2(_0444_),
    .B1(_0137_),
    .Y(_0521_));
 sky130_fd_sc_hd__nand2_1 _1386_ (.A(net6),
    .B(_0503_),
    .Y(_0523_));
 sky130_fd_sc_hd__nand2_1 _1387_ (.A(net81),
    .B(_0076_),
    .Y(_0524_));
 sky130_fd_sc_hd__and2_1 _1388_ (.A(net114),
    .B(net3),
    .X(_0884_));
 sky130_fd_sc_hd__a31oi_1 _1389_ (.A1(net102),
    .A2(_0523_),
    .A3(_0524_),
    .B1(net4),
    .Y(_0525_));
 sky130_fd_sc_hd__nor4_1 _1390_ (.A(net97),
    .B(net95),
    .C(_0521_),
    .D(_0525_),
    .Y(_0526_));
 sky130_fd_sc_hd__a21oi_1 _1391_ (.A1(net100),
    .A2(_0304_),
    .B1(_0193_),
    .Y(_0527_));
 sky130_fd_sc_hd__o32ai_1 _1392_ (.A1(_0138_),
    .A2(_0444_),
    .A3(_0527_),
    .B1(_0425_),
    .B2(_0044_),
    .Y(_0528_));
 sky130_fd_sc_hd__o21ai_0 _1393_ (.A1(net92),
    .A2(_0268_),
    .B1(net81),
    .Y(_0529_));
 sky130_fd_sc_hd__o21ai_0 _1394_ (.A1(_0046_),
    .A2(_0329_),
    .B1(net107),
    .Y(_0530_));
 sky130_fd_sc_hd__and4_1 _1395_ (.A(_0138_),
    .B(_0169_),
    .C(_0529_),
    .D(_0530_),
    .X(_0531_));
 sky130_fd_sc_hd__o21a_1 _1396_ (.A1(_0528_),
    .A2(_0531_),
    .B1(net97),
    .X(_0532_));
 sky130_fd_sc_hd__nand3_1 _1397_ (.A(net97),
    .B(net95),
    .C(_0205_),
    .Y(_0534_));
 sky130_fd_sc_hd__a311oi_1 _1398_ (.A1(net97),
    .A2(net98),
    .A3(_0173_),
    .B1(net83),
    .C1(net105),
    .Y(_0535_));
 sky130_fd_sc_hd__a31o_2 _1400_ (.A1(net105),
    .A2(net86),
    .A3(_0534_),
    .B1(_0535_),
    .X(_0536_));
 sky130_fd_sc_hd__or3_1 _1401_ (.A(net92),
    .B(_0205_),
    .C(_0324_),
    .X(_0537_));
 sky130_fd_sc_hd__a21oi_1 _1402_ (.A1(net110),
    .A2(net82),
    .B1(_0169_),
    .Y(_0538_));
 sky130_fd_sc_hd__a22oi_1 _1403_ (.A1(net105),
    .A2(_0249_),
    .B1(_0502_),
    .B2(net93),
    .Y(_0539_));
 sky130_fd_sc_hd__o221ai_1 _1404_ (.A1(net95),
    .A2(_0538_),
    .B1(_0539_),
    .B2(net110),
    .C1(net97),
    .Y(_0540_));
 sky130_fd_sc_hd__a31oi_1 _1405_ (.A1(_0072_),
    .A2(_0536_),
    .A3(_0537_),
    .B1(_0540_),
    .Y(_0541_));
 sky130_fd_sc_hd__o311ai_1 _1406_ (.A1(_0526_),
    .A2(_0532_),
    .A3(_0541_),
    .B1(net96),
    .C1(net9),
    .Y(_0542_));
 sky130_fd_sc_hd__nand4_1 _1407_ (.A(_0474_),
    .B(_0508_),
    .C(_0520_),
    .D(_0542_),
    .Y(_0009_));
 sky130_fd_sc_hd__nor2_1 _1408_ (.A(net92),
    .B(_0243_),
    .Y(_0543_));
 sky130_fd_sc_hd__o21ai_0 _1409_ (.A1(net84),
    .A2(_0543_),
    .B1(net107),
    .Y(_0544_));
 sky130_fd_sc_hd__a31oi_1 _1411_ (.A1(net83),
    .A2(_0216_),
    .A3(_0258_),
    .B1(net81),
    .Y(_0545_));
 sky130_fd_sc_hd__a21oi_1 _1412_ (.A1(net111),
    .A2(_0258_),
    .B1(net107),
    .Y(_0546_));
 sky130_fd_sc_hd__o21ai_0 _1413_ (.A1(_0112_),
    .A2(_0546_),
    .B1(_0138_),
    .Y(_0547_));
 sky130_fd_sc_hd__a31oi_1 _1414_ (.A1(_0544_),
    .A2(_0545_),
    .A3(_0547_),
    .B1(_0315_),
    .Y(_0548_));
 sky130_fd_sc_hd__o22ai_1 _1415_ (.A1(_0099_),
    .A2(net93),
    .B1(net86),
    .B2(_0072_),
    .Y(_0549_));
 sky130_fd_sc_hd__a221oi_1 _1416_ (.A1(_0251_),
    .A2(net88),
    .B1(_0549_),
    .B2(net109),
    .C1(net92),
    .Y(_0550_));
 sky130_fd_sc_hd__nor3_1 _1417_ (.A(net103),
    .B(net83),
    .C(_0127_),
    .Y(_0551_));
 sky130_fd_sc_hd__o221ai_1 _1418_ (.A1(net109),
    .A2(_0414_),
    .B1(_0550_),
    .B2(_0551_),
    .C1(net81),
    .Y(_0552_));
 sky130_fd_sc_hd__nor2_1 _1419_ (.A(net96),
    .B(_0505_),
    .Y(_0554_));
 sky130_fd_sc_hd__nor3_1 _1420_ (.A(net94),
    .B(_0201_),
    .C(_0304_),
    .Y(_0555_));
 sky130_fd_sc_hd__and2_1 _1421_ (.A(net98),
    .B(net104),
    .X(_0032_));
 sky130_fd_sc_hd__a21oi_1 _1422_ (.A1(net81),
    .A2(_0117_),
    .B1(net4),
    .Y(_0556_));
 sky130_fd_sc_hd__a22oi_1 _1423_ (.A1(net92),
    .A2(net93),
    .B1(_0503_),
    .B2(net100),
    .Y(_0557_));
 sky130_fd_sc_hd__o32ai_1 _1424_ (.A1(net110),
    .A2(_0555_),
    .A3(_0556_),
    .B1(_0557_),
    .B2(net4),
    .Y(_0558_));
 sky130_fd_sc_hd__nor3_1 _1425_ (.A(net95),
    .B(_0292_),
    .C(_0558_),
    .Y(_0559_));
 sky130_fd_sc_hd__a221oi_1 _1426_ (.A1(_0548_),
    .A2(_0552_),
    .B1(_0554_),
    .B2(_0088_),
    .C1(_0559_),
    .Y(_0560_));
 sky130_fd_sc_hd__a22oi_1 _1427_ (.A1(net112),
    .A2(net95),
    .B1(_0046_),
    .B2(net102),
    .Y(_0561_));
 sky130_fd_sc_hd__o21ai_0 _1428_ (.A1(_0032_),
    .A2(_0329_),
    .B1(net112),
    .Y(_0562_));
 sky130_fd_sc_hd__nand2_1 _1429_ (.A(net94),
    .B(net117),
    .Y(_0563_));
 sky130_fd_sc_hd__nand2_1 _1430_ (.A(net101),
    .B(_0563_),
    .Y(_0565_));
 sky130_fd_sc_hd__o211ai_1 _1431_ (.A1(net106),
    .A2(_0561_),
    .B1(_0562_),
    .C1(_0565_),
    .Y(_0566_));
 sky130_fd_sc_hd__a21oi_1 _1433_ (.A1(_0036_),
    .A2(_0134_),
    .B1(_0409_),
    .Y(_0567_));
 sky130_fd_sc_hd__o22ai_1 _1434_ (.A1(net107),
    .A2(_0216_),
    .B1(_0567_),
    .B2(net100),
    .Y(_0568_));
 sky130_fd_sc_hd__o22ai_1 _1435_ (.A1(_0099_),
    .A2(_0294_),
    .B1(_0128_),
    .B2(_0385_),
    .Y(_0569_));
 sky130_fd_sc_hd__nand2_1 _1436_ (.A(net106),
    .B(_0569_),
    .Y(_0570_));
 sky130_fd_sc_hd__nand2_1 _1437_ (.A(net97),
    .B(_0570_),
    .Y(_0571_));
 sky130_fd_sc_hd__a221oi_1 _1438_ (.A1(_0138_),
    .A2(_0566_),
    .B1(_0568_),
    .B2(_0099_),
    .C1(_0571_),
    .Y(_0572_));
 sky130_fd_sc_hd__nor2_1 _1439_ (.A(net81),
    .B(_0385_),
    .Y(_0573_));
 sky130_fd_sc_hd__o21ai_0 _1440_ (.A1(_0197_),
    .A2(_0573_),
    .B1(_0181_),
    .Y(_0574_));
 sky130_fd_sc_hd__o21ai_0 _1441_ (.A1(_0112_),
    .A2(_0173_),
    .B1(net107),
    .Y(_0576_));
 sky130_fd_sc_hd__mux2i_1 _1442_ (.A0(net113),
    .A1(_0064_),
    .S(net101),
    .Y(_0577_));
 sky130_fd_sc_hd__o21ai_0 _1444_ (.A1(net115),
    .A2(net83),
    .B1(_0032_),
    .Y(_0034_));
 sky130_fd_sc_hd__nand2b_1 _1445_ (.A_N(_0577_),
    .B(net115),
    .Y(_0578_));
 sky130_fd_sc_hd__a31oi_1 _1446_ (.A1(_0574_),
    .A2(_0576_),
    .A3(_0578_),
    .B1(net110),
    .Y(_0579_));
 sky130_fd_sc_hd__o21ai_0 _1447_ (.A1(net81),
    .A2(net93),
    .B1(_0106_),
    .Y(_0580_));
 sky130_fd_sc_hd__a31oi_1 _1448_ (.A1(net109),
    .A2(net103),
    .A3(_0580_),
    .B1(net97),
    .Y(_0581_));
 sky130_fd_sc_hd__o21a_1 _1449_ (.A1(_0257_),
    .A2(_0042_),
    .B1(net92),
    .X(_0582_));
 sky130_fd_sc_hd__o21ai_0 _1450_ (.A1(_0348_),
    .A2(_0582_),
    .B1(net81),
    .Y(_0583_));
 sky130_fd_sc_hd__nand2_1 _1451_ (.A(_0581_),
    .B(_0583_),
    .Y(_0584_));
 sky130_fd_sc_hd__nor4_1 _1452_ (.A(net9),
    .B(_0079_),
    .C(_0082_),
    .D(_0292_),
    .Y(_0585_));
 sky130_fd_sc_hd__o22ai_1 _1453_ (.A1(_0579_),
    .A2(_0584_),
    .B1(_0585_),
    .B2(net90),
    .Y(_0587_));
 sky130_fd_sc_hd__o22ai_1 _1454_ (.A1(_0283_),
    .A2(_0560_),
    .B1(_0572_),
    .B2(_0587_),
    .Y(_0021_));
 sky130_fd_sc_hd__o221a_1 _1455_ (.A1(net102),
    .A2(_0713_),
    .B1(_0850_),
    .B2(net114),
    .C1(_0034_),
    .X(_0035_));
 sky130_fd_sc_hd__o21ai_0 _1456_ (.A1(net113),
    .A2(_0184_),
    .B1(net107),
    .Y(_0588_));
 sky130_fd_sc_hd__a21oi_1 _1457_ (.A1(_0309_),
    .A2(_0588_),
    .B1(net81),
    .Y(_0589_));
 sky130_fd_sc_hd__a22oi_1 _1458_ (.A1(net81),
    .A2(_0076_),
    .B1(_0418_),
    .B2(net94),
    .Y(_0590_));
 sky130_fd_sc_hd__o22ai_1 _1459_ (.A1(net107),
    .A2(_0185_),
    .B1(_0590_),
    .B2(net102),
    .Y(_0591_));
 sky130_fd_sc_hd__o21ai_0 _1460_ (.A1(_0589_),
    .A2(_0591_),
    .B1(net115),
    .Y(_0592_));
 sky130_fd_sc_hd__nor2_1 _1461_ (.A(net92),
    .B(_0235_),
    .Y(_0593_));
 sky130_fd_sc_hd__o21ai_0 _1462_ (.A1(_0202_),
    .A2(_0593_),
    .B1(_0281_),
    .Y(_0594_));
 sky130_fd_sc_hd__a21oi_1 _1463_ (.A1(net100),
    .A2(_0207_),
    .B1(net95),
    .Y(_0595_));
 sky130_fd_sc_hd__o22ai_1 _1464_ (.A1(net93),
    .A2(_0401_),
    .B1(_0595_),
    .B2(net107),
    .Y(_0597_));
 sky130_fd_sc_hd__o21ai_0 _1465_ (.A1(net113),
    .A2(_0404_),
    .B1(net102),
    .Y(_0598_));
 sky130_fd_sc_hd__nand2b_1 _1466_ (.A_N(net114),
    .B(net116),
    .Y(_0036_));
 sky130_fd_sc_hd__a21oi_1 _1467_ (.A1(_0038_),
    .A2(_0598_),
    .B1(_0444_),
    .Y(_0599_));
 sky130_fd_sc_hd__a21oi_1 _1468_ (.A1(net111),
    .A2(_0597_),
    .B1(_0599_),
    .Y(_0600_));
 sky130_fd_sc_hd__and3_1 _1469_ (.A(net89),
    .B(_0594_),
    .C(_0600_),
    .X(_0601_));
 sky130_fd_sc_hd__nand2_1 _1470_ (.A(net97),
    .B(net90),
    .Y(_0602_));
 sky130_fd_sc_hd__a21oi_1 _1471_ (.A1(net94),
    .A2(net83),
    .B1(_0127_),
    .Y(_0603_));
 sky130_fd_sc_hd__o22ai_1 _1472_ (.A1(net83),
    .A2(_0425_),
    .B1(_0603_),
    .B2(net81),
    .Y(_0604_));
 sky130_fd_sc_hd__a22oi_1 _1473_ (.A1(_0076_),
    .A2(_0063_),
    .B1(_0604_),
    .B2(net117),
    .Y(_0605_));
 sky130_fd_sc_hd__a21oi_1 _1474_ (.A1(net94),
    .A2(_0076_),
    .B1(_0502_),
    .Y(_0606_));
 sky130_fd_sc_hd__nand3_1 _1475_ (.A(net117),
    .B(net90),
    .C(_0606_),
    .Y(_0608_));
 sky130_fd_sc_hd__o31ai_1 _1476_ (.A1(net103),
    .A2(_0602_),
    .A3(_0605_),
    .B1(_0608_),
    .Y(_0609_));
 sky130_fd_sc_hd__a31oi_1 _1478_ (.A1(net106),
    .A2(_0234_),
    .A3(_0235_),
    .B1(_0193_),
    .Y(_0610_));
 sky130_fd_sc_hd__a21oi_1 _1479_ (.A1(net102),
    .A2(_0042_),
    .B1(_0112_),
    .Y(_0611_));
 sky130_fd_sc_hd__o221ai_1 _1480_ (.A1(net112),
    .A2(_0610_),
    .B1(_0611_),
    .B2(_0231_),
    .C1(_0138_),
    .Y(_0612_));
 sky130_fd_sc_hd__a21oi_1 _1481_ (.A1(net106),
    .A2(_0235_),
    .B1(_0329_),
    .Y(_0613_));
 sky130_fd_sc_hd__o221ai_1 _1482_ (.A1(_0276_),
    .A2(_0231_),
    .B1(_0613_),
    .B2(_0099_),
    .C1(net114),
    .Y(_0614_));
 sky130_fd_sc_hd__a32oi_1 _1483_ (.A1(_0159_),
    .A2(_0385_),
    .A3(_0404_),
    .B1(_0193_),
    .B2(_0046_),
    .Y(_0615_));
 sky130_fd_sc_hd__nand3_1 _1484_ (.A(net100),
    .B(net111),
    .C(net82),
    .Y(_0616_));
 sky130_fd_sc_hd__o21ai_0 _1485_ (.A1(net111),
    .A2(_0249_),
    .B1(net95),
    .Y(_0617_));
 sky130_fd_sc_hd__nand3_1 _1486_ (.A(_0615_),
    .B(_0616_),
    .C(_0617_),
    .Y(_0619_));
 sky130_fd_sc_hd__a221oi_1 _1487_ (.A1(_0612_),
    .A2(_0614_),
    .B1(_0619_),
    .B2(net94),
    .C1(net97),
    .Y(_0620_));
 sky130_fd_sc_hd__nand2b_1 _1488_ (.A_N(net116),
    .B(net114),
    .Y(_0038_));
 sky130_fd_sc_hd__o21ai_0 _1489_ (.A1(_0304_),
    .A2(_0173_),
    .B1(net106),
    .Y(_0621_));
 sky130_fd_sc_hd__o22ai_1 _1490_ (.A1(net104),
    .A2(_0432_),
    .B1(_0068_),
    .B2(_0262_),
    .Y(_0622_));
 sky130_fd_sc_hd__o21ai_0 _1491_ (.A1(net106),
    .A2(net111),
    .B1(net114),
    .Y(_0623_));
 sky130_fd_sc_hd__a221o_1 _1492_ (.A1(_0432_),
    .A2(net85),
    .B1(_0623_),
    .B2(net104),
    .C1(_0072_),
    .X(_0624_));
 sky130_fd_sc_hd__o21ai_1 _1493_ (.A1(net116),
    .A2(_0622_),
    .B1(_0624_),
    .Y(_0625_));
 sky130_fd_sc_hd__a21oi_1 _1494_ (.A1(_0621_),
    .A2(_0625_),
    .B1(_0318_),
    .Y(_0626_));
 sky130_fd_sc_hd__o21ai_0 _1495_ (.A1(_0207_),
    .A2(_0352_),
    .B1(net102),
    .Y(_0627_));
 sky130_fd_sc_hd__a21oi_1 _1496_ (.A1(_0068_),
    .A2(_0627_),
    .B1(net94),
    .Y(_0628_));
 sky130_fd_sc_hd__nand2_1 _1497_ (.A(net92),
    .B(_0503_),
    .Y(_0630_));
 sky130_fd_sc_hd__o211ai_1 _1498_ (.A1(_0099_),
    .A2(net93),
    .B1(_0339_),
    .C1(_0630_),
    .Y(_0631_));
 sky130_fd_sc_hd__nand2_1 _1499_ (.A(_0036_),
    .B(_0038_),
    .Y(_0039_));
 sky130_fd_sc_hd__o31ai_1 _1500_ (.A1(_0324_),
    .A2(_0628_),
    .A3(_0631_),
    .B1(net96),
    .Y(_0632_));
 sky130_fd_sc_hd__nand2_1 _1501_ (.A(_0173_),
    .B(net88),
    .Y(_0633_));
 sky130_fd_sc_hd__o21ai_1 _1502_ (.A1(net105),
    .A2(_0269_),
    .B1(net111),
    .Y(_0634_));
 sky130_fd_sc_hd__o21ai_1 _1503_ (.A1(net92),
    .A2(_0249_),
    .B1(net105),
    .Y(_0635_));
 sky130_fd_sc_hd__o21ai_0 _1504_ (.A1(_0401_),
    .A2(net88),
    .B1(net97),
    .Y(_0636_));
 sky130_fd_sc_hd__a41oi_1 _1505_ (.A1(net98),
    .A2(_0633_),
    .A3(_0634_),
    .A4(_0635_),
    .B1(_0636_),
    .Y(_0637_));
 sky130_fd_sc_hd__nor2_1 _1506_ (.A(net104),
    .B(_0086_),
    .Y(_0638_));
 sky130_fd_sc_hd__nand2b_1 _1507_ (.A_N(net97),
    .B(net98),
    .Y(_0639_));
 sky130_fd_sc_hd__nor2_1 _1508_ (.A(_0638_),
    .B(_0639_),
    .Y(_0641_));
 sky130_fd_sc_hd__or3_1 _1509_ (.A(net96),
    .B(_0637_),
    .C(_0641_),
    .X(_0642_));
 sky130_fd_sc_hd__nand2b_1 _1510_ (.A_N(net112),
    .B(net100),
    .Y(_0040_));
 sky130_fd_sc_hd__o311a_1 _1511_ (.A1(_0620_),
    .A2(_0626_),
    .A3(_0632_),
    .B1(_0642_),
    .C1(net9),
    .X(_0643_));
 sky130_fd_sc_hd__a211o_1 _1512_ (.A1(_0592_),
    .A2(_0601_),
    .B1(_0609_),
    .C1(_0643_),
    .X(_0000_));
 sky130_fd_sc_hd__or4_1 _1513_ (.A(net9),
    .B(_0079_),
    .C(_0563_),
    .D(_0292_),
    .X(_0644_));
 sky130_fd_sc_hd__nor2_1 _1514_ (.A(_0425_),
    .B(_0503_),
    .Y(_0645_));
 sky130_fd_sc_hd__a21oi_1 _1515_ (.A1(net109),
    .A2(_0432_),
    .B1(_0169_),
    .Y(_0646_));
 sky130_fd_sc_hd__a21oi_1 _1516_ (.A1(net101),
    .A2(_0504_),
    .B1(net102),
    .Y(_0647_));
 sky130_fd_sc_hd__o31a_1 _1517_ (.A1(_0645_),
    .A2(_0646_),
    .A3(_0647_),
    .B1(_0060_),
    .X(_0648_));
 sky130_fd_sc_hd__o21ai_0 _1518_ (.A1(_0432_),
    .A2(_0235_),
    .B1(_0068_),
    .Y(_0649_));
 sky130_fd_sc_hd__nand3_1 _1519_ (.A(net109),
    .B(net103),
    .C(net113),
    .Y(_0651_));
 sky130_fd_sc_hd__a21oi_1 _1520_ (.A1(_0347_),
    .A2(_0651_),
    .B1(_0072_),
    .Y(_0652_));
 sky130_fd_sc_hd__o21a_1 _1522_ (.A1(net117),
    .A2(net113),
    .B1(net110),
    .X(_0653_));
 sky130_fd_sc_hd__o21ai_0 _1523_ (.A1(net101),
    .A2(_0190_),
    .B1(net103),
    .Y(_0654_));
 sky130_fd_sc_hd__o211ai_1 _1524_ (.A1(_0653_),
    .A2(_0425_),
    .B1(_0056_),
    .C1(_0654_),
    .Y(_0655_));
 sky130_fd_sc_hd__a2111oi_0 _1525_ (.A1(net109),
    .A2(_0649_),
    .B1(_0652_),
    .C1(_0060_),
    .D1(_0655_),
    .Y(_0656_));
 sky130_fd_sc_hd__o21ai_0 _1526_ (.A1(net115),
    .A2(_0068_),
    .B1(_0036_),
    .Y(_0657_));
 sky130_fd_sc_hd__a21oi_1 _1527_ (.A1(net110),
    .A2(_0117_),
    .B1(net4),
    .Y(_0658_));
 sky130_fd_sc_hd__a211oi_1 _1528_ (.A1(net4),
    .A2(_0657_),
    .B1(_0658_),
    .C1(_0076_),
    .Y(_0659_));
 sky130_fd_sc_hd__o21ai_0 _1529_ (.A1(_0502_),
    .A2(_0659_),
    .B1(net96),
    .Y(_0660_));
 sky130_fd_sc_hd__o31ai_1 _1530_ (.A1(_0648_),
    .A2(_0656_),
    .A3(_0660_),
    .B1(_0284_),
    .Y(_0662_));
 sky130_fd_sc_hd__o22ai_1 _1531_ (.A1(_0223_),
    .A2(_0068_),
    .B1(_0169_),
    .B2(_0144_),
    .Y(_0663_));
 sky130_fd_sc_hd__nor2b_1 _1532_ (.A(net115),
    .B_N(net112),
    .Y(_0042_));
 sky130_fd_sc_hd__nand2_1 _1533_ (.A(net109),
    .B(_0663_),
    .Y(_0664_));
 sky130_fd_sc_hd__o21ai_0 _1534_ (.A1(_0225_),
    .A2(_0516_),
    .B1(_0046_),
    .Y(_0665_));
 sky130_fd_sc_hd__nand3_1 _1535_ (.A(_0403_),
    .B(_0664_),
    .C(_0665_),
    .Y(_0666_));
 sky130_fd_sc_hd__a21oi_1 _1536_ (.A1(net115),
    .A2(_0347_),
    .B1(net106),
    .Y(_0667_));
 sky130_fd_sc_hd__a311o_1 _1537_ (.A1(net106),
    .A2(_0128_),
    .A3(_0347_),
    .B1(_0667_),
    .C1(net102),
    .X(_0668_));
 sky130_fd_sc_hd__nand2_1 _1538_ (.A(net99),
    .B(_0042_),
    .Y(_0669_));
 sky130_fd_sc_hd__a21oi_1 _1539_ (.A1(_0668_),
    .A2(_0669_),
    .B1(net114),
    .Y(_0670_));
 sky130_fd_sc_hd__o22a_1 _1540_ (.A1(net92),
    .A2(_0503_),
    .B1(_0418_),
    .B2(_0280_),
    .X(_0671_));
 sky130_fd_sc_hd__nand2_1 _1541_ (.A(net86),
    .B(_0205_),
    .Y(_0673_));
 sky130_fd_sc_hd__a22oi_1 _1542_ (.A1(net111),
    .A2(_0207_),
    .B1(_0673_),
    .B2(net115),
    .Y(_0674_));
 sky130_fd_sc_hd__nand2_1 _1544_ (.A(net109),
    .B(net95),
    .Y(_0675_));
 sky130_fd_sc_hd__o22ai_1 _1545_ (.A1(net82),
    .A2(_0040_),
    .B1(_0185_),
    .B2(net93),
    .Y(_0676_));
 sky130_fd_sc_hd__a21oi_1 _1546_ (.A1(net103),
    .A2(_0676_),
    .B1(net97),
    .Y(_0677_));
 sky130_fd_sc_hd__o221ai_1 _1547_ (.A1(net109),
    .A2(_0671_),
    .B1(_0674_),
    .B2(_0675_),
    .C1(_0677_),
    .Y(_0678_));
 sky130_fd_sc_hd__o211ai_1 _1548_ (.A1(_0666_),
    .A2(_0670_),
    .B1(net90),
    .C1(_0678_),
    .Y(_0679_));
 sky130_fd_sc_hd__nand3_1 _1549_ (.A(_0644_),
    .B(_0662_),
    .C(_0679_),
    .Y(_0023_));
 sky130_fd_sc_hd__o22ai_1 _1550_ (.A1(net86),
    .A2(_0216_),
    .B1(_0258_),
    .B2(_0205_),
    .Y(_0680_));
 sky130_fd_sc_hd__a21oi_1 _1551_ (.A1(net104),
    .A2(_0038_),
    .B1(net82),
    .Y(_0681_));
 sky130_fd_sc_hd__o221ai_1 _1552_ (.A1(_0275_),
    .A2(_0038_),
    .B1(_0681_),
    .B2(net3),
    .C1(net106),
    .Y(_0683_));
 sky130_fd_sc_hd__o21a_1 _1553_ (.A1(net106),
    .A2(_0680_),
    .B1(_0683_),
    .X(_0684_));
 sky130_fd_sc_hd__nand2_1 _1555_ (.A(net102),
    .B(_0042_),
    .Y(_0044_));
 sky130_fd_sc_hd__nand2_1 _1556_ (.A(net106),
    .B(net116),
    .Y(_0685_));
 sky130_fd_sc_hd__nand3_1 _1557_ (.A(net104),
    .B(_0796_),
    .C(_0144_),
    .Y(_0686_));
 sky130_fd_sc_hd__or2_1 _1558_ (.A(net102),
    .B(net110),
    .X(_0687_));
 sky130_fd_sc_hd__a21oi_1 _1559_ (.A1(_0275_),
    .A2(_0687_),
    .B1(_0337_),
    .Y(_0688_));
 sky130_fd_sc_hd__a211oi_1 _1560_ (.A1(_0133_),
    .A2(net85),
    .B1(_0688_),
    .C1(net114),
    .Y(_0689_));
 sky130_fd_sc_hd__a311oi_1 _1561_ (.A1(net114),
    .A2(_0685_),
    .A3(_0686_),
    .B1(_0689_),
    .C1(net81),
    .Y(_0690_));
 sky130_fd_sc_hd__a21oi_1 _1562_ (.A1(net81),
    .A2(_0684_),
    .B1(_0690_),
    .Y(_0691_));
 sky130_fd_sc_hd__o221ai_1 _1563_ (.A1(net86),
    .A2(_0226_),
    .B1(_0691_),
    .B2(_0153_),
    .C1(_0533_),
    .Y(_0018_));
 sky130_fd_sc_hd__nor2_1 _1564_ (.A(net99),
    .B(net111),
    .Y(_0693_));
 sky130_fd_sc_hd__o22ai_1 _1565_ (.A1(net99),
    .A2(_0036_),
    .B1(_0112_),
    .B2(_0418_),
    .Y(_0694_));
 sky130_fd_sc_hd__o21ai_0 _1566_ (.A1(_0039_),
    .A2(_0040_),
    .B1(_0044_),
    .Y(_0045_));
 sky130_fd_sc_hd__a22oi_1 _1567_ (.A1(_0348_),
    .A2(_0693_),
    .B1(_0694_),
    .B2(net111),
    .Y(_0695_));
 sky130_fd_sc_hd__nor2_1 _1568_ (.A(net109),
    .B(_0695_),
    .Y(_0696_));
 sky130_fd_sc_hd__a21oi_1 _1569_ (.A1(_0796_),
    .A2(_0565_),
    .B1(_0159_),
    .Y(_0697_));
 sky130_fd_sc_hd__nor2_1 _1570_ (.A(net106),
    .B(net83),
    .Y(_0698_));
 sky130_fd_sc_hd__a21oi_1 _1571_ (.A1(_0818_),
    .A2(_0337_),
    .B1(net114),
    .Y(_0699_));
 sky130_fd_sc_hd__nor2_1 _1572_ (.A(_0060_),
    .B(net6),
    .Y(_0700_));
 sky130_fd_sc_hd__o21ai_0 _1573_ (.A1(net104),
    .A2(_0046_),
    .B1(net108),
    .Y(_0701_));
 sky130_fd_sc_hd__nand4_1 _1574_ (.A(_0106_),
    .B(_0700_),
    .C(_0258_),
    .D(_0701_),
    .Y(_0702_));
 sky130_fd_sc_hd__o32a_1 _1575_ (.A1(net115),
    .A2(_0698_),
    .A3(_0502_),
    .B1(_0699_),
    .B2(_0702_),
    .X(_0704_));
 sky130_fd_sc_hd__o31ai_1 _1576_ (.A1(net97),
    .A2(_0696_),
    .A3(_0697_),
    .B1(_0704_),
    .Y(_0705_));
 sky130_fd_sc_hd__nor2_2 _1577_ (.A(net116),
    .B(net3),
    .Y(_0046_));
 sky130_fd_sc_hd__a21o_1 _1578_ (.A1(net103),
    .A2(_0086_),
    .B1(_0451_),
    .X(_0706_));
 sky130_fd_sc_hd__a22o_1 _1579_ (.A1(net90),
    .A2(_0705_),
    .B1(_0706_),
    .B2(_0091_),
    .X(_0026_));
 sky130_fd_sc_hd__a22oi_1 _1580_ (.A1(_0039_),
    .A2(_0193_),
    .B1(_0495_),
    .B2(_0207_),
    .Y(_0707_));
 sky130_fd_sc_hd__o221ai_1 _1581_ (.A1(_0275_),
    .A2(_0117_),
    .B1(_0707_),
    .B2(net110),
    .C1(net94),
    .Y(_0708_));
 sky130_fd_sc_hd__o32ai_1 _1582_ (.A1(_0144_),
    .A2(_0173_),
    .A3(_0269_),
    .B1(_0038_),
    .B2(_0275_),
    .Y(_0709_));
 sky130_fd_sc_hd__nand2_1 _1583_ (.A(net101),
    .B(_0709_),
    .Y(_0710_));
 sky130_fd_sc_hd__o21bai_1 _1584_ (.A1(_0249_),
    .A2(_0426_),
    .B1_N(_0185_),
    .Y(_0711_));
 sky130_fd_sc_hd__a31oi_1 _1585_ (.A1(net109),
    .A2(_0710_),
    .A3(_0711_),
    .B1(_0153_),
    .Y(_0712_));
 sky130_fd_sc_hd__nor2_1 _1586_ (.A(net115),
    .B(_0432_),
    .Y(_0714_));
 sky130_fd_sc_hd__o22ai_1 _1587_ (.A1(_0653_),
    .A2(_0425_),
    .B1(_0231_),
    .B2(_0714_),
    .Y(_0715_));
 sky130_fd_sc_hd__nor2b_1 _1588_ (.A(net113),
    .B_N(net1),
    .Y(_0047_));
 sky130_fd_sc_hd__nor2_1 _1589_ (.A(net94),
    .B(_0347_),
    .Y(_0716_));
 sky130_fd_sc_hd__o21ai_0 _1590_ (.A1(net88),
    .A2(_0716_),
    .B1(net103),
    .Y(_0717_));
 sky130_fd_sc_hd__o221ai_1 _1591_ (.A1(net109),
    .A2(_0196_),
    .B1(_0715_),
    .B2(net103),
    .C1(_0717_),
    .Y(_0718_));
 sky130_fd_sc_hd__a21oi_1 _1592_ (.A1(net4),
    .A2(_0503_),
    .B1(net103),
    .Y(_0719_));
 sky130_fd_sc_hd__o32ai_1 _1593_ (.A1(net97),
    .A2(_0687_),
    .A3(_0504_),
    .B1(_0719_),
    .B2(_0228_),
    .Y(_0720_));
 sky130_fd_sc_hd__a21oi_1 _1594_ (.A1(net101),
    .A2(_0720_),
    .B1(_0229_),
    .Y(_0721_));
 sky130_fd_sc_hd__a21oi_1 _1595_ (.A1(net97),
    .A2(_0718_),
    .B1(_0721_),
    .Y(_0722_));
 sky130_fd_sc_hd__o2bb2ai_1 _1596_ (.A1_N(_0708_),
    .A2_N(_0712_),
    .B1(_0722_),
    .B2(_0533_),
    .Y(_0012_));
 sky130_fd_sc_hd__nor2_1 _1597_ (.A(net99),
    .B(_0159_),
    .Y(_0724_));
 sky130_fd_sc_hd__o21ai_0 _1598_ (.A1(_0573_),
    .A2(_0724_),
    .B1(net115),
    .Y(_0725_));
 sky130_fd_sc_hd__nand2_1 _1600_ (.A(net111),
    .B(_0258_),
    .Y(_0726_));
 sky130_fd_sc_hd__a32oi_1 _1601_ (.A1(_0072_),
    .A2(_0385_),
    .A3(_0693_),
    .B1(_0726_),
    .B2(_0516_),
    .Y(_0727_));
 sky130_fd_sc_hd__mux2_2 _1602_ (.A0(net114),
    .A1(net116),
    .S(net98),
    .X(_0728_));
 sky130_fd_sc_hd__a221oi_1 _1603_ (.A1(_0076_),
    .A2(_0128_),
    .B1(_0728_),
    .B2(net3),
    .C1(_0311_),
    .Y(_0729_));
 sky130_fd_sc_hd__a31oi_1 _1604_ (.A1(net114),
    .A2(_0242_),
    .A3(_0032_),
    .B1(net107),
    .Y(_0730_));
 sky130_fd_sc_hd__o21a_1 _1605_ (.A1(net102),
    .A2(_0729_),
    .B1(_0730_),
    .X(_0731_));
 sky130_fd_sc_hd__a311oi_1 _1606_ (.A1(net107),
    .A2(_0725_),
    .A3(_0727_),
    .B1(net97),
    .C1(_0731_),
    .Y(_0732_));
 sky130_fd_sc_hd__nor2_1 _1607_ (.A(_0064_),
    .B(_0409_),
    .Y(_0733_));
 sky130_fd_sc_hd__a22oi_1 _1608_ (.A1(net110),
    .A2(net82),
    .B1(_0038_),
    .B2(net92),
    .Y(_0735_));
 sky130_fd_sc_hd__o22ai_1 _1609_ (.A1(net110),
    .A2(_0733_),
    .B1(_0735_),
    .B2(net105),
    .Y(_0736_));
 sky130_fd_sc_hd__o21ai_0 _1611_ (.A1(net104),
    .A2(_0144_),
    .B1(_0796_),
    .Y(_0737_));
 sky130_fd_sc_hd__nor3_1 _1612_ (.A(net105),
    .B(net117),
    .C(net83),
    .Y(_0738_));
 sky130_fd_sc_hd__a31oi_1 _1613_ (.A1(net105),
    .A2(net113),
    .A3(_0737_),
    .B1(_0738_),
    .Y(_0739_));
 sky130_fd_sc_hd__o22ai_1 _1614_ (.A1(_0318_),
    .A2(_0736_),
    .B1(_0739_),
    .B2(_0324_),
    .Y(_0740_));
 sky130_fd_sc_hd__o21ai_0 _1615_ (.A1(_0732_),
    .A2(_0740_),
    .B1(net90),
    .Y(_0741_));
 sky130_fd_sc_hd__o21ai_0 _1616_ (.A1(net81),
    .A2(_0719_),
    .B1(_0060_),
    .Y(_0742_));
 sky130_fd_sc_hd__o211ai_1 _1617_ (.A1(net94),
    .A2(_0714_),
    .B1(_0495_),
    .C1(net97),
    .Y(_0743_));
 sky130_fd_sc_hd__a21oi_1 _1618_ (.A1(net81),
    .A2(_0653_),
    .B1(net103),
    .Y(_0744_));
 sky130_fd_sc_hd__o221ai_1 _1619_ (.A1(_0414_),
    .A2(_0169_),
    .B1(_0744_),
    .B2(net109),
    .C1(_0675_),
    .Y(_0746_));
 sky130_fd_sc_hd__nand2b_1 _1620_ (.A_N(net109),
    .B(net101),
    .Y(_0747_));
 sky130_fd_sc_hd__inv_1 _1621_ (.A(net98),
    .Y(_0050_));
 sky130_fd_sc_hd__o22ai_1 _1622_ (.A1(_0117_),
    .A2(_0747_),
    .B1(_0401_),
    .B2(_0251_),
    .Y(_0748_));
 sky130_fd_sc_hd__a21oi_1 _1623_ (.A1(net110),
    .A2(_0748_),
    .B1(_0060_),
    .Y(_0749_));
 sky130_fd_sc_hd__nand2_1 _1624_ (.A(_0746_),
    .B(_0749_),
    .Y(_0750_));
 sky130_fd_sc_hd__a41o_1 _1625_ (.A1(net96),
    .A2(_0742_),
    .A3(_0743_),
    .A4(_0750_),
    .B1(_0093_),
    .X(_0751_));
 sky130_fd_sc_hd__nand3b_1 _1626_ (.A_N(_0585_),
    .B(_0741_),
    .C(_0751_),
    .Y(_0024_));
 sky130_fd_sc_hd__o22ai_1 _1627_ (.A1(_0084_),
    .A2(_0090_),
    .B1(_0074_),
    .B2(_0602_),
    .Y(_0006_));
 sky130_fd_sc_hd__a221oi_1 _1628_ (.A1(_0432_),
    .A2(_0181_),
    .B1(_0414_),
    .B2(net109),
    .C1(_0352_),
    .Y(_0752_));
 sky130_fd_sc_hd__o211ai_1 _1629_ (.A1(_0257_),
    .A2(net87),
    .B1(net101),
    .C1(net115),
    .Y(_0753_));
 sky130_fd_sc_hd__o21ai_0 _1630_ (.A1(net101),
    .A2(_0752_),
    .B1(_0753_),
    .Y(_0755_));
 sky130_fd_sc_hd__a21oi_1 _1631_ (.A1(_0038_),
    .A2(_0264_),
    .B1(net84),
    .Y(_0756_));
 sky130_fd_sc_hd__o22ai_1 _1633_ (.A1(_0068_),
    .A2(_0563_),
    .B1(_0756_),
    .B2(net94),
    .Y(_0757_));
 sky130_fd_sc_hd__a222oi_1 _1634_ (.A1(_0134_),
    .A2(_0352_),
    .B1(_0755_),
    .B2(net103),
    .C1(net81),
    .C2(_0757_),
    .Y(_0758_));
 sky130_fd_sc_hd__nor4_1 _1635_ (.A(net94),
    .B(_0414_),
    .C(_0169_),
    .D(_0315_),
    .Y(_0759_));
 sky130_fd_sc_hd__o221ai_1 _1636_ (.A1(_0602_),
    .A2(_0758_),
    .B1(_0759_),
    .B2(_0093_),
    .C1(_0644_),
    .Y(_0027_));
 sky130_fd_sc_hd__nand2_1 _1637_ (.A(net86),
    .B(_0185_),
    .Y(_0760_));
 sky130_fd_sc_hd__a21oi_1 _1638_ (.A1(_0138_),
    .A2(_0040_),
    .B1(_0072_),
    .Y(_0761_));
 sky130_fd_sc_hd__o21ai_0 _1639_ (.A1(_0760_),
    .A2(_0761_),
    .B1(net103),
    .Y(_0762_));
 sky130_fd_sc_hd__o21ai_0 _1640_ (.A1(net101),
    .A2(_0414_),
    .B1(_0762_),
    .Y(_0763_));
 sky130_fd_sc_hd__a21oi_1 _1641_ (.A1(net101),
    .A2(net87),
    .B1(_0693_),
    .Y(_0765_));
 sky130_fd_sc_hd__o21ai_0 _1642_ (.A1(net94),
    .A2(net93),
    .B1(_0099_),
    .Y(_0766_));
 sky130_fd_sc_hd__a22oi_1 _1644_ (.A1(_0251_),
    .A2(_0063_),
    .B1(_0766_),
    .B2(net101),
    .Y(_0767_));
 sky130_fd_sc_hd__a211oi_1 _1645_ (.A1(net91),
    .A2(_0466_),
    .B1(_0315_),
    .C1(_0283_),
    .Y(_0768_));
 sky130_fd_sc_hd__o221ai_1 _1646_ (.A1(net109),
    .A2(_0765_),
    .B1(_0767_),
    .B2(net103),
    .C1(_0768_),
    .Y(_0769_));
 sky130_fd_sc_hd__a21oi_1 _1647_ (.A1(net109),
    .A2(_0763_),
    .B1(_0769_),
    .Y(_0770_));
 sky130_fd_sc_hd__maj3_1 _1648_ (.A(net4),
    .B(net81),
    .C(_0432_),
    .X(_0771_));
 sky130_fd_sc_hd__a221oi_1 _1649_ (.A1(net101),
    .A2(_0719_),
    .B1(_0771_),
    .B2(net102),
    .C1(_0292_),
    .Y(_0772_));
 sky130_fd_sc_hd__o21ai_1 _1650_ (.A1(_0507_),
    .A2(_0772_),
    .B1(net9),
    .Y(_0773_));
 sky130_fd_sc_hd__o21ai_0 _1651_ (.A1(net117),
    .A2(_0485_),
    .B1(_0773_),
    .Y(_0774_));
 sky130_fd_sc_hd__o21ai_0 _1652_ (.A1(net111),
    .A2(_0401_),
    .B1(_0231_),
    .Y(_0776_));
 sky130_fd_sc_hd__o21ai_0 _1653_ (.A1(_0042_),
    .A2(_0202_),
    .B1(net81),
    .Y(_0777_));
 sky130_fd_sc_hd__o21ai_0 _1654_ (.A1(_0046_),
    .A2(net82),
    .B1(net81),
    .Y(_0053_));
 sky130_fd_sc_hd__a221oi_1 _1655_ (.A1(net111),
    .A2(net95),
    .B1(_0032_),
    .B2(_0144_),
    .C1(net107),
    .Y(_0778_));
 sky130_fd_sc_hd__a31oi_1 _1656_ (.A1(net107),
    .A2(_0510_),
    .A3(_0777_),
    .B1(_0778_),
    .Y(_0779_));
 sky130_fd_sc_hd__a21oi_1 _1657_ (.A1(net115),
    .A2(_0776_),
    .B1(_0779_),
    .Y(_0780_));
 sky130_fd_sc_hd__o21ai_0 _1658_ (.A1(net100),
    .A2(_0068_),
    .B1(_0040_),
    .Y(_0781_));
 sky130_fd_sc_hd__a222oi_1 _1659_ (.A1(net83),
    .A2(_0193_),
    .B1(_0202_),
    .B2(net100),
    .C1(net106),
    .C2(_0781_),
    .Y(_0782_));
 sky130_fd_sc_hd__o21ai_0 _1660_ (.A1(net100),
    .A2(net112),
    .B1(_0515_),
    .Y(_0783_));
 sky130_fd_sc_hd__a221oi_1 _1661_ (.A1(_0196_),
    .A2(net85),
    .B1(_0783_),
    .B2(net114),
    .C1(net116),
    .Y(_0784_));
 sky130_fd_sc_hd__a21o_1 _1662_ (.A1(net116),
    .A2(_0782_),
    .B1(_0784_),
    .X(_0785_));
 sky130_fd_sc_hd__a21oi_1 _1663_ (.A1(net91),
    .A2(net85),
    .B1(_0153_),
    .Y(_0787_));
 sky130_fd_sc_hd__o211ai_1 _1664_ (.A1(net113),
    .A2(_0780_),
    .B1(_0785_),
    .C1(_0787_),
    .Y(_0788_));
 sky130_fd_sc_hd__or3b_1 _1667_ (.A(_0770_),
    .B(_0774_),
    .C_N(_0788_),
    .X(_0010_));
 sky130_fd_sc_hd__a31oi_1 _1668_ (.A1(net4),
    .A2(net102),
    .A3(_0503_),
    .B1(_0324_),
    .Y(_0789_));
 sky130_fd_sc_hd__a21oi_1 _1669_ (.A1(_0415_),
    .A2(_0789_),
    .B1(_0506_),
    .Y(_0790_));
 sky130_fd_sc_hd__o21ai_0 _1670_ (.A1(net96),
    .A2(_0790_),
    .B1(net9),
    .Y(_0791_));
 sky130_fd_sc_hd__nor2_1 _1671_ (.A(net117),
    .B(net88),
    .Y(_0792_));
 sky130_fd_sc_hd__xnor2_1 _1672_ (.A(net113),
    .B(_0792_),
    .Y(_0793_));
 sky130_fd_sc_hd__a31oi_1 _1673_ (.A1(net92),
    .A2(_0700_),
    .A3(_0793_),
    .B1(_0228_),
    .Y(_0794_));
 sky130_fd_sc_hd__nor2_1 _1674_ (.A(net104),
    .B(_0268_),
    .Y(_0795_));
 sky130_fd_sc_hd__a22oi_1 _1675_ (.A1(net104),
    .A2(net91),
    .B1(_0205_),
    .B2(_0072_),
    .Y(_0797_));
 sky130_fd_sc_hd__nor2b_1 _1676_ (.A(net105),
    .B_N(net114),
    .Y(_0798_));
 sky130_fd_sc_hd__o21ai_0 _1678_ (.A1(_0072_),
    .A2(_0798_),
    .B1(_0264_),
    .Y(_0799_));
 sky130_fd_sc_hd__o221ai_1 _1679_ (.A1(_0140_),
    .A2(_0795_),
    .B1(_0797_),
    .B2(net106),
    .C1(_0799_),
    .Y(_0800_));
 sky130_fd_sc_hd__a21oi_1 _1680_ (.A1(net6),
    .A2(_0800_),
    .B1(_0060_),
    .Y(_0801_));
 sky130_fd_sc_hd__o22ai_1 _1681_ (.A1(_0099_),
    .A2(_0036_),
    .B1(_0038_),
    .B2(_0327_),
    .Y(_0802_));
 sky130_fd_sc_hd__a211oi_1 _1682_ (.A1(net111),
    .A2(_0038_),
    .B1(net82),
    .C1(net105),
    .Y(_0803_));
 sky130_fd_sc_hd__a21oi_1 _1683_ (.A1(_0099_),
    .A2(_0036_),
    .B1(net94),
    .Y(_0804_));
 sky130_fd_sc_hd__nor3_1 _1684_ (.A(net98),
    .B(_0803_),
    .C(_0804_),
    .Y(_0805_));
 sky130_fd_sc_hd__o21ai_0 _1685_ (.A1(_0802_),
    .A2(_0805_),
    .B1(net104),
    .Y(_0806_));
 sky130_fd_sc_hd__o21ai_0 _1686_ (.A1(net110),
    .A2(_0117_),
    .B1(_0205_),
    .Y(_0808_));
 sky130_fd_sc_hd__a21oi_1 _1687_ (.A1(net6),
    .A2(_0808_),
    .B1(net88),
    .Y(_0809_));
 sky130_fd_sc_hd__nand2_1 _1688_ (.A(net101),
    .B(net83),
    .Y(_0056_));
 sky130_fd_sc_hd__o22ai_1 _1689_ (.A1(_0432_),
    .A2(_0401_),
    .B1(_0335_),
    .B2(_0796_),
    .Y(_0810_));
 sky130_fd_sc_hd__nor3_1 _1690_ (.A(net105),
    .B(net98),
    .C(_0076_),
    .Y(_0811_));
 sky130_fd_sc_hd__a21oi_1 _1691_ (.A1(net105),
    .A2(_0810_),
    .B1(_0811_),
    .Y(_0812_));
 sky130_fd_sc_hd__o21ai_0 _1692_ (.A1(net105),
    .A2(net117),
    .B1(net113),
    .Y(_0813_));
 sky130_fd_sc_hd__a32oi_1 _1693_ (.A1(net105),
    .A2(net93),
    .A3(net86),
    .B1(_0813_),
    .B2(_0099_),
    .Y(_0814_));
 sky130_fd_sc_hd__nand3_1 _1694_ (.A(_0032_),
    .B(_0106_),
    .C(_0814_),
    .Y(_0815_));
 sky130_fd_sc_hd__o2111a_1 _1695_ (.A1(net102),
    .A2(_0809_),
    .B1(_0812_),
    .C1(_0815_),
    .D1(_0060_),
    .X(_0816_));
 sky130_fd_sc_hd__a211o_1 _1696_ (.A1(_0801_),
    .A2(_0806_),
    .B1(_0816_),
    .C1(_0791_),
    .X(_0817_));
 sky130_fd_sc_hd__nor3_1 _1697_ (.A(net109),
    .B(net101),
    .C(net110),
    .Y(_0819_));
 sky130_fd_sc_hd__a21oi_1 _1698_ (.A1(_0818_),
    .A2(_0185_),
    .B1(net109),
    .Y(_0820_));
 sky130_fd_sc_hd__nand2_1 _1700_ (.A(net113),
    .B(_0401_),
    .Y(_0821_));
 sky130_fd_sc_hd__o32ai_1 _1701_ (.A1(net113),
    .A2(_0187_),
    .A3(_0819_),
    .B1(_0820_),
    .B2(_0821_),
    .Y(_0822_));
 sky130_fd_sc_hd__o22ai_1 _1702_ (.A1(net86),
    .A2(_0226_),
    .B1(_0822_),
    .B2(_0153_),
    .Y(_0823_));
 sky130_fd_sc_hd__o22ai_1 _1703_ (.A1(net102),
    .A2(_0068_),
    .B1(_0159_),
    .B2(net110),
    .Y(_0824_));
 sky130_fd_sc_hd__a22o_1 _1704_ (.A1(net87),
    .A2(net85),
    .B1(_0824_),
    .B2(net107),
    .X(_0825_));
 sky130_fd_sc_hd__nand3_1 _1705_ (.A(net103),
    .B(_0063_),
    .C(net89),
    .Y(_0826_));
 sky130_fd_sc_hd__a21oi_1 _1706_ (.A1(_0485_),
    .A2(_0826_),
    .B1(net113),
    .Y(_0827_));
 sky130_fd_sc_hd__a311o_1 _1707_ (.A1(net100),
    .A2(net89),
    .A3(_0825_),
    .B1(_0827_),
    .C1(net117),
    .X(_0828_));
 sky130_fd_sc_hd__o21ai_0 _1708_ (.A1(_0072_),
    .A2(_0823_),
    .B1(_0828_),
    .Y(_0830_));
 sky130_fd_sc_hd__o211ai_1 _1709_ (.A1(_0791_),
    .A2(_0794_),
    .B1(_0817_),
    .C1(_0830_),
    .Y(_0008_));
 sky130_fd_sc_hd__a21oi_1 _1710_ (.A1(_0053_),
    .A2(_0056_),
    .B1(net103),
    .Y(_0058_));
 sky130_fd_sc_hd__o21ai_0 _1711_ (.A1(net92),
    .A2(_0042_),
    .B1(net106),
    .Y(_0831_));
 sky130_fd_sc_hd__a21oi_1 _1712_ (.A1(_0276_),
    .A2(_0831_),
    .B1(_0138_),
    .Y(_0832_));
 sky130_fd_sc_hd__a21oi_1 _1713_ (.A1(net106),
    .A2(_0275_),
    .B1(_0036_),
    .Y(_0833_));
 sky130_fd_sc_hd__o21ai_0 _1714_ (.A1(_0832_),
    .A2(_0833_),
    .B1(net81),
    .Y(_0834_));
 sky130_fd_sc_hd__o21ai_0 _1715_ (.A1(net106),
    .A2(_0099_),
    .B1(_0385_),
    .Y(_0835_));
 sky130_fd_sc_hd__a32oi_1 _1716_ (.A1(net106),
    .A2(_0276_),
    .A3(_0159_),
    .B1(_0835_),
    .B2(net116),
    .Y(_0836_));
 sky130_fd_sc_hd__a21oi_1 _1717_ (.A1(_0747_),
    .A2(_0444_),
    .B1(_0159_),
    .Y(_0837_));
 sky130_fd_sc_hd__a21oi_1 _1718_ (.A1(_0159_),
    .A2(net88),
    .B1(_0837_),
    .Y(_0838_));
 sky130_fd_sc_hd__o22a_1 _1719_ (.A1(net81),
    .A2(_0836_),
    .B1(_0838_),
    .B2(net116),
    .X(_0840_));
 sky130_fd_sc_hd__o211ai_1 _1720_ (.A1(net86),
    .A2(_0685_),
    .B1(_0834_),
    .C1(_0840_),
    .Y(_0841_));
 sky130_fd_sc_hd__o21ai_0 _1721_ (.A1(_0045_),
    .A2(_0058_),
    .B1(net109),
    .Y(_0059_));
 sky130_fd_sc_hd__o21ai_1 _1722_ (.A1(net111),
    .A2(_0207_),
    .B1(net102),
    .Y(_0842_));
 sky130_fd_sc_hd__o21ai_1 _1723_ (.A1(_0133_),
    .A2(_0274_),
    .B1(_0138_),
    .Y(_0843_));
 sky130_fd_sc_hd__nand2_1 _1724_ (.A(_0842_),
    .B(_0843_),
    .Y(_0844_));
 sky130_fd_sc_hd__nand3_1 _1725_ (.A(net115),
    .B(net86),
    .C(_0205_),
    .Y(_0845_));
 sky130_fd_sc_hd__nor2_1 _1726_ (.A(net104),
    .B(_0361_),
    .Y(_0846_));
 sky130_fd_sc_hd__a221oi_1 _1727_ (.A1(net104),
    .A2(net93),
    .B1(_0845_),
    .B2(_0846_),
    .C1(net106),
    .Y(_0847_));
 sky130_fd_sc_hd__a2111oi_1 _1728_ (.A1(net106),
    .A2(_0844_),
    .B1(_0847_),
    .C1(net97),
    .D1(net98),
    .Y(_0848_));
 sky130_fd_sc_hd__o22ai_1 _1729_ (.A1(net104),
    .A2(_0432_),
    .B1(_0068_),
    .B2(net115),
    .Y(_0849_));
 sky130_fd_sc_hd__a21oi_1 _1730_ (.A1(net91),
    .A2(_0466_),
    .B1(_0264_),
    .Y(_0851_));
 sky130_fd_sc_hd__a31oi_1 _1731_ (.A1(_0205_),
    .A2(_0144_),
    .A3(_0309_),
    .B1(_0639_),
    .Y(_0852_));
 sky130_fd_sc_hd__clkinv_1 _1732_ (.A(net97),
    .Y(_0060_));
 sky130_fd_sc_hd__o21ai_0 _1733_ (.A1(net105),
    .A2(_0851_),
    .B1(_0852_),
    .Y(_0853_));
 sky130_fd_sc_hd__a21oi_1 _1734_ (.A1(net105),
    .A2(_0849_),
    .B1(_0853_),
    .Y(_0854_));
 sky130_fd_sc_hd__a211oi_1 _1735_ (.A1(_0432_),
    .A2(_0114_),
    .B1(_0169_),
    .C1(_0072_),
    .Y(_0855_));
 sky130_fd_sc_hd__nor2_1 _1736_ (.A(_0099_),
    .B(net82),
    .Y(_0856_));
 sky130_fd_sc_hd__o2111ai_1 _1737_ (.A1(net109),
    .A2(_0068_),
    .B1(_0444_),
    .C1(_0495_),
    .D1(net115),
    .Y(_0857_));
 sky130_fd_sc_hd__o311ai_0 _1738_ (.A1(net109),
    .A2(_0223_),
    .A3(_0856_),
    .B1(_0857_),
    .C1(net97),
    .Y(_0858_));
 sky130_fd_sc_hd__o21ai_0 _1739_ (.A1(_0855_),
    .A2(_0858_),
    .B1(net90),
    .Y(_0859_));
 sky130_fd_sc_hd__nor3_1 _1740_ (.A(_0848_),
    .B(_0854_),
    .C(_0859_),
    .Y(_0860_));
 sky130_fd_sc_hd__nor3_1 _1741_ (.A(_0283_),
    .B(_0228_),
    .C(net97),
    .Y(_0862_));
 sky130_fd_sc_hd__a21oi_1 _1742_ (.A1(_0439_),
    .A2(_0630_),
    .B1(net81),
    .Y(_0863_));
 sky130_fd_sc_hd__a22oi_1 _1744_ (.A1(net99),
    .A2(_0042_),
    .B1(_0216_),
    .B2(_0693_),
    .Y(_0864_));
 sky130_fd_sc_hd__o21ai_0 _1745_ (.A1(net114),
    .A2(_0864_),
    .B1(net106),
    .Y(_0865_));
 sky130_fd_sc_hd__a22oi_1 _1746_ (.A1(net99),
    .A2(_0251_),
    .B1(_0117_),
    .B2(net103),
    .Y(_0866_));
 sky130_fd_sc_hd__o22ai_1 _1747_ (.A1(_0418_),
    .A2(_0726_),
    .B1(_0866_),
    .B2(net111),
    .Y(_0867_));
 sky130_fd_sc_hd__a2bb2oi_1 _1748_ (.A1_N(_0863_),
    .A2_N(_0865_),
    .B1(net94),
    .B2(_0867_),
    .Y(_0868_));
 sky130_fd_sc_hd__a211oi_1 _1749_ (.A1(_0405_),
    .A2(_0789_),
    .B1(_0283_),
    .C1(net96),
    .Y(_0869_));
 sky130_fd_sc_hd__a22o_1 _1750_ (.A1(_0862_),
    .A2(_0868_),
    .B1(_0869_),
    .B2(_0088_),
    .X(_0870_));
 sky130_fd_sc_hd__a311o_1 _1751_ (.A1(net9),
    .A2(_0229_),
    .A3(_0841_),
    .B1(_0860_),
    .C1(_0870_),
    .X(_0011_));
 sky130_fd_sc_hd__a22oi_1 _1752_ (.A1(_0184_),
    .A2(_0287_),
    .B1(_0673_),
    .B2(net85),
    .Y(_0872_));
 sky130_fd_sc_hd__o21ai_0 _1753_ (.A1(_0274_),
    .A2(_0348_),
    .B1(net109),
    .Y(_0873_));
 sky130_fd_sc_hd__o211ai_1 _1754_ (.A1(net109),
    .A2(_0035_),
    .B1(_0059_),
    .C1(_0060_),
    .Y(_0062_));
 sky130_fd_sc_hd__a21oi_1 _1755_ (.A1(_0872_),
    .A2(_0873_),
    .B1(net101),
    .Y(_0874_));
 sky130_fd_sc_hd__o21ai_0 _1756_ (.A1(_0099_),
    .A2(_0036_),
    .B1(net86),
    .Y(_0875_));
 sky130_fd_sc_hd__a21oi_1 _1757_ (.A1(net109),
    .A2(_0875_),
    .B1(_0714_),
    .Y(_0876_));
 sky130_fd_sc_hd__o32a_1 _1758_ (.A1(net115),
    .A2(_0068_),
    .A3(_0747_),
    .B1(_0444_),
    .B2(_0036_),
    .X(_0877_));
 sky130_fd_sc_hd__o221ai_1 _1759_ (.A1(_0169_),
    .A2(_0876_),
    .B1(_0877_),
    .B2(net103),
    .C1(net89),
    .Y(_0878_));
 sky130_fd_sc_hd__nor2_1 _1760_ (.A(_0284_),
    .B(_0182_),
    .Y(_0879_));
 sky130_fd_sc_hd__o21ai_0 _1761_ (.A1(_0874_),
    .A2(_0878_),
    .B1(_0879_),
    .Y(_0005_));
 sky130_fd_sc_hd__nor2_1 _1762_ (.A(net109),
    .B(net101),
    .Y(_0063_));
 sky130_fd_sc_hd__nor2_2 _1764_ (.A(net103),
    .B(net113),
    .Y(_0064_));
 sky130_fd_sc_hd__nand2_1 _1765_ (.A(_0063_),
    .B(_0064_),
    .Y(_0065_));
 sky130_fd_sc_hd__nand2_2 _1768_ (.A(net114),
    .B(net3),
    .Y(_0068_));
 sky130_fd_sc_hd__nand2_1 _1770_ (.A(net107),
    .B(net103),
    .Y(_0070_));
 sky130_fd_sc_hd__nor2_1 _1771_ (.A(_0068_),
    .B(_0070_),
    .Y(_0071_));
 sky130_fd_sc_hd__clkinv_1 _1772_ (.A(net117),
    .Y(_0072_));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_sys_clk (.A(sys_clk),
    .X(clknet_0_sys_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_2_0__f_sys_clk (.A(clknet_0_sys_clk),
    .X(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_2_1__f_sys_clk (.A(clknet_0_sys_clk),
    .X(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_2_2__f_sys_clk (.A(clknet_0_sys_clk),
    .X(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_2_3__f_sys_clk (.A(clknet_0_sys_clk),
    .X(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__bufinv_16 clkload0 (.A(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__inv_6 clkload1 (.A(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__clkinvlp_4 clkload2 (.A(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[0]$_DFF_P_  (.D(_0000_),
    .Q(net10),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[10]$_DFF_P_  (.D(_0001_),
    .Q(net11),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[11]$_DFF_P_  (.D(_0002_),
    .Q(net12),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[12]$_DFF_P_  (.D(_0003_),
    .Q(net13),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[13]$_DFF_P_  (.D(_0004_),
    .Q(net14),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[14]$_DFF_P_  (.D(_0005_),
    .Q(net15),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[15]$_DFF_P_  (.D(_0006_),
    .Q(net16),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[16]$_DFF_P_  (.D(_0007_),
    .Q(net17),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[17]$_DFF_P_  (.D(_0008_),
    .Q(net18),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[18]$_DFF_P_  (.D(_0009_),
    .Q(net19),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[19]$_DFF_P_  (.D(_0010_),
    .Q(net20),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[1]$_DFF_P_  (.D(_0011_),
    .Q(net21),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[20]$_DFF_P_  (.D(_0012_),
    .Q(net22),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[21]$_DFF_P_  (.D(_0013_),
    .Q(net23),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[22]$_DFF_P_  (.D(_0014_),
    .Q(net24),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[23]$_SDFF_PN0_  (.D(_0030_),
    .Q(net25),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[24]$_DFF_P_  (.D(_0015_),
    .Q(net26),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[25]$_DFF_P_  (.D(_0016_),
    .Q(net27),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[26]$_DFF_P_  (.D(_0017_),
    .Q(net28),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[27]$_DFF_P_  (.D(_0018_),
    .Q(net29),
    .CLK(clknet_2_0__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[28]$_DFF_P_  (.D(_0019_),
    .Q(net30),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[29]$_DFF_P_  (.D(_0020_),
    .Q(net31),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[2]$_DFF_P_  (.D(_0021_),
    .Q(net32),
    .CLK(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[30]$_DFF_P_  (.D(_0022_),
    .Q(net33),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[31]$_SDFF_PN0_  (.D(_0031_),
    .Q(net34),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[3]$_DFF_P_  (.D(_0023_),
    .Q(net35),
    .CLK(clknet_2_2__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[4]$_DFF_P_  (.D(_0024_),
    .Q(net36),
    .CLK(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[5]$_DFF_P_  (.D(_0025_),
    .Q(net37),
    .CLK(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[6]$_DFF_P_  (.D(_0026_),
    .Q(net38),
    .CLK(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[7]$_DFF_P_  (.D(_0027_),
    .Q(net39),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[8]$_DFF_P_  (.D(_0028_),
    .Q(net40),
    .CLK(clknet_2_1__leaf_sys_clk));
 sky130_fd_sc_hd__dfxtp_1 \data[9]$_DFF_P_  (.D(_0029_),
    .Q(net41),
    .CLK(clknet_2_3__leaf_sys_clk));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input1 (.A(address[0]),
    .X(net1));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input2 (.A(address[1]),
    .X(net2));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input3 (.A(address[2]),
    .X(net3));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input4 (.A(address[3]),
    .X(net4));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input5 (.A(address[4]),
    .X(net5));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input6 (.A(address[5]),
    .X(net6));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input7 (.A(address[6]),
    .X(net7));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input8 (.A(address[7]),
    .X(net8));
 sky130_fd_sc_hd__clkdlybuf4s50_1 input9 (.A(address[8]),
    .X(net9));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output10 (.A(net10),
    .X(data[0]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output11 (.A(net11),
    .X(data[10]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output12 (.A(net12),
    .X(data[11]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output13 (.A(net13),
    .X(data[12]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output14 (.A(net14),
    .X(data[13]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output15 (.A(net15),
    .X(data[14]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output16 (.A(net16),
    .X(data[15]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output17 (.A(net17),
    .X(data[16]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output18 (.A(net18),
    .X(data[17]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output19 (.A(net19),
    .X(data[18]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output20 (.A(net20),
    .X(data[19]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output21 (.A(net21),
    .X(data[1]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output22 (.A(net22),
    .X(data[20]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output23 (.A(net23),
    .X(data[21]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output24 (.A(net24),
    .X(data[22]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output25 (.A(net25),
    .X(data[23]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output26 (.A(net26),
    .X(data[24]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output27 (.A(net27),
    .X(data[25]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output28 (.A(net28),
    .X(data[26]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output29 (.A(net29),
    .X(data[27]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output30 (.A(net30),
    .X(data[28]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output31 (.A(net31),
    .X(data[29]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output32 (.A(net32),
    .X(data[2]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output33 (.A(net33),
    .X(data[30]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output34 (.A(net34),
    .X(data[31]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output35 (.A(net35),
    .X(data[3]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output36 (.A(net36),
    .X(data[4]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output37 (.A(net37),
    .X(data[5]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output38 (.A(net38),
    .X(data[6]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output39 (.A(net39),
    .X(data[7]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output40 (.A(net40),
    .X(data[8]));
 sky130_fd_sc_hd__clkdlybuf4s50_1 output41 (.A(net41),
    .X(data[9]));
 sky130_fd_sc_hd__buf_4 place100 (.A(net6),
    .X(net100));
 sky130_fd_sc_hd__buf_4 place101 (.A(net6),
    .X(net101));
 sky130_fd_sc_hd__buf_4 place102 (.A(net104),
    .X(net102));
 sky130_fd_sc_hd__buf_4 place103 (.A(net104),
    .X(net103));
 sky130_fd_sc_hd__buf_4 place104 (.A(net5),
    .X(net104));
 sky130_fd_sc_hd__buf_4 place105 (.A(net4),
    .X(net105));
 sky130_fd_sc_hd__buf_4 place106 (.A(net108),
    .X(net106));
 sky130_fd_sc_hd__buf_4 place107 (.A(net108),
    .X(net107));
 sky130_fd_sc_hd__buf_4 place108 (.A(net4),
    .X(net108));
 sky130_fd_sc_hd__buf_4 place109 (.A(net4),
    .X(net109));
 sky130_fd_sc_hd__buf_4 place110 (.A(net112),
    .X(net110));
 sky130_fd_sc_hd__buf_4 place111 (.A(net112),
    .X(net111));
 sky130_fd_sc_hd__buf_4 place112 (.A(net3),
    .X(net112));
 sky130_fd_sc_hd__buf_4 place113 (.A(net114),
    .X(net113));
 sky130_fd_sc_hd__buf_4 place114 (.A(net2),
    .X(net114));
 sky130_fd_sc_hd__buf_4 place115 (.A(net116),
    .X(net115));
 sky130_fd_sc_hd__buf_4 place116 (.A(net1),
    .X(net116));
 sky130_fd_sc_hd__buf_4 place117 (.A(net1),
    .X(net117));
 sky130_fd_sc_hd__buf_4 place81 (.A(_0050_),
    .X(net81));
 sky130_fd_sc_hd__buf_4 place82 (.A(_0047_),
    .X(net82));
 sky130_fd_sc_hd__buf_4 place83 (.A(_0884_),
    .X(net83));
 sky130_fd_sc_hd__buf_4 place84 (.A(_0361_),
    .X(net84));
 sky130_fd_sc_hd__buf_4 place85 (.A(_0289_),
    .X(net85));
 sky130_fd_sc_hd__buf_4 place86 (.A(_0682_),
    .X(net86));
 sky130_fd_sc_hd__buf_4 place87 (.A(_0672_),
    .X(net87));
 sky130_fd_sc_hd__buf_4 place88 (.A(_0191_),
    .X(net88));
 sky130_fd_sc_hd__buf_4 place89 (.A(_0189_),
    .X(net89));
 sky130_fd_sc_hd__buf_4 place90 (.A(_0553_),
    .X(net90));
 sky130_fd_sc_hd__buf_4 place91 (.A(_0171_),
    .X(net91));
 sky130_fd_sc_hd__buf_4 place92 (.A(_0135_),
    .X(net92));
 sky130_fd_sc_hd__buf_4 place93 (.A(_0102_),
    .X(net93));
 sky130_fd_sc_hd__buf_4 place94 (.A(_0080_),
    .X(net94));
 sky130_fd_sc_hd__buf_4 place95 (.A(_0078_),
    .X(net95));
 sky130_fd_sc_hd__buf_4 place96 (.A(net8),
    .X(net96));
 sky130_fd_sc_hd__buf_4 place97 (.A(net7),
    .X(net97));
 sky130_fd_sc_hd__buf_4 place98 (.A(net6),
    .X(net98));
 sky130_fd_sc_hd__buf_4 place99 (.A(net100),
    .X(net99));
endmodule
